export type PageView =
  | 'home'
  | 'shop'
  | 'product'
  | 'cart'
  | 'checkout'
  | 'account'
  | 'about'
  | 'contact'
  | 'faq';

export type CategorySlug =
  | 'all'
  | 'distillates'
  | 'pickles'
  | 'jams'
  | 'syrups'
  | 'spices'
  | 'local-foods';

export interface CategoryInfo {
  slug: Exclude<CategorySlug, 'all'>;
  title: string;
  shortTitle: string;
  description: string;
  image: string;
  seasonTag: string;
}

export interface ProductVariant {
  id: string;
  label: string;
  price: number;
}

export interface ProductReview {
  id: string;
  author: string;
  city: string;
  date: string;
  rating: number;
  comment: string;
  purchasedProduct?: string;
  isSample?: boolean;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: Exclude<CategorySlug, 'all'>;
  categoryLabel: string;
  price: number;
  weight: string;
  inStock: boolean;
  badge?: 'پرفروش' | 'محبوب' | 'تازه رسیده' | 'پیشنهاد گلابتون';
  ratingPlaceholder: number;
  reviewCountPlaceholder: number;
  image: string;
  gallery: string[];
  shortDescription: string;
  fullDescription: string;
  ingredients: string[];
  specifications: { label: string; value: string }[];
  storageInstructions: string;
  packagingNote: string;
  variants?: ProductVariant[];
  popularityScore: number;
  isNew?: boolean;
  season?: 'بهار' | 'تابستان' | 'پاییز' | 'زمستان';
}

export interface CartItem {
  productId: string;
  variantId?: string;
  variantLabel: string;
  name: string;
  categoryLabel: string;
  price: number;
  image: string;
  quantity: number;
}

export interface SavedAddress {
  id: string;
  title: string;
  recipient: string;
  mobile: string;
  province: string;
  city: string;
  address: string;
  postalCode: string;
  isDefault?: boolean;
}

export interface OrderRecord {
  id: string;
  orderNumber: string;
  createdAt: string;
  status: 'در حال آماده‌سازی' | 'تحویل به پست' | 'تکمیل شده';
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingCost: number;
  total: number;
  recipientName: string;
  mobile: string;
  addressSummary: string;
  deliveryMethod: string;
  paymentMethod: string;
  notes?: string;
}

export interface RecipeArticle {
  id: string;
  title: string;
  category: string;
  readingTime: string;
  excerpt: string;
  image: string;
  ingredients: string[];
  steps: string[];
  relatedCategory: CategorySlug;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  group: string;
}

export interface UserProfile {
  isAuthenticated: boolean;
  fullName: string;
  mobile: string;
  email: string;
}
