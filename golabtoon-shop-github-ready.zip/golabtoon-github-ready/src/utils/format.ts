export const IMAGE_ASSETS = {
  heroTable: '/src/assets/images/hero_persian_table_1794745454592.jpg',
  distillates: '/src/assets/images/cat_herbal_distillates_1794745455357.jpg',
  pickles: '/src/assets/images/cat_homemade_pickles_1794745455565.jpg',
  jams: '/src/assets/images/cat_jams_syrups_1794745455435.jpg',
  syrups: '/src/assets/images/cat_traditional_syrups_1794745455731.jpg',
  spices: '/src/assets/images/cat_spices_condiments_1794745455602.jpg',
  localFoods: '/src/assets/images/cat_local_foods_1794745457507.jpg',
  brandStory: '/src/assets/images/brand_story_kitchen_1794745458237.jpg',
} as const;

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/\d/g, (digit) => PERSIAN_DIGITS[Number(digit)] ?? digit);
}

export function formatToman(amount: number): string {
  const formatted = new Intl.NumberFormat('en-US').format(Math.max(0, Math.round(amount)));
  return toPersianDigits(formatted);
}

export function formatPriceWithUnit(amount: number): string {
  return `${formatToman(amount)} تومان`;
}
