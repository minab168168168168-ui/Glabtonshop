import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { CartItem, PageView } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';

interface CartDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onUpdateQty: (productId: string, variantId: string | undefined, delta: number) => void;
  onRemoveItem: (productId: string, variantId: string | undefined) => void;
  onNavigate: (page: PageView) => void;
}

const FREE_SHIPPING_THRESHOLD = 1500000;

export function CartDrawer({
  isOpen,
  items,
  onClose,
  onUpdateQty,
  onRemoveItem,
  onNavigate,
}: CartDrawerProps) {
  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progressPercent = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="سبد خرید">
      <div
        className="fixed inset-0 bg-[#263F32]/45 backdrop-blur-xs"
        onClick={onClose}
      />

      <aside className="relative z-10 w-full max-w-md bg-[#F8F4EA] h-full shadow-2xl border-r border-[#B69A64]/30 flex flex-col">
        <div className="px-6 py-4 border-b border-[#B69A64]/25 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#263F32]" />
            <h2 className="text-base font-bold text-[#263F32]">
              سبد خرید شما ({toPersianDigits(items.reduce((s, i) => s + i.quantity, 0))})
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="بستن سبد خرید"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-[#49382D] hover:bg-[#EEE5D4] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {items.length > 0 && (
          <div className="px-6 py-3 bg-[#EEE5D4]/65 border-b border-[#B69A64]/20">
            <p className="text-xs text-[#49382D] mb-2">
              {remainingForFreeShipping === 0
                ? 'سفارش شما شامل ارسال رایگان است.'
                : `${formatToman(remainingForFreeShipping)} تومان تا ارسال رایگان باقی مانده است.`}
            </p>
            <div className="h-1.5 w-full rounded-full bg-[#F8F4EA] overflow-hidden">
              <div
                className="h-full bg-[#263F32] transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#EEE5D4] flex items-center justify-center text-[#68744B]">
                <ShoppingBag className="w-7 h-7" strokeWidth={1.5} />
              </div>
              <div className="space-y-1.5">
                <p className="text-base font-bold text-[#263F32]">سبد خرید شما هنوز خالی است!</p>
                <p className="text-xs text-[#49382D]/75">
                  وقتشه طعم‌های خوش گلابتون رو کشف کنید.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigate('shop');
                }}
                className="px-6 py-2.5 rounded-xl bg-[#263F32] text-[#F8F4EA] text-sm font-medium hover:bg-[#1E3328] transition-colors cursor-pointer"
              >
                مشاهده محصولات
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={`${item.productId}-${item.variantId || 'default'}`}
                  className="flex gap-3.5 pb-4 border-b border-[#B69A64]/20"
                >
                  <BrandImage
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-16 rounded-xl shrink-0"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-[#263F32] truncate">{item.name}</p>
                        <p className="text-xs text-[#68744B] mt-0.5">{item.variantLabel}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.productId, item.variantId)}
                        aria-label={`حذف ${item.name}`}
                        className="text-[#49382D]/55 hover:text-[#AD684F] p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <div className="inline-flex items-center border border-[#B69A64]/35 rounded-lg bg-[#F8F4EA]">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.productId, item.variantId, 1)}
                          aria-label="افزایش تعداد"
                          className="w-7 h-7 flex items-center justify-center text-[#263F32] hover:bg-[#EEE5D4] cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-8 text-center text-xs font-semibold tabular-nums text-[#263F32]">
                          {toPersianDigits(item.quantity)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.productId, item.variantId, -1)}
                          aria-label="کاهش تعداد"
                          className="w-7 h-7 flex items-center justify-center text-[#263F32] hover:bg-[#EEE5D4] cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="text-sm font-bold text-[#263F32] tabular-nums">
                        {formatToman(item.price * item.quantity)} تومان
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="p-6 border-t border-[#B69A64]/30 bg-[#EEE5D4]/55 space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#49382D]">جمع کل محصولات</span>
              <span className="text-base font-bold text-[#263F32] tabular-nums">
                {formatToman(subtotal)} تومان
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigate('cart');
                }}
                className="py-3 rounded-xl border border-[#263F32] text-[#263F32] text-sm font-medium hover:bg-[#EEE5D4] transition-colors cursor-pointer"
              >
                مشاهده سبد خرید
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigate('checkout');
                }}
                className="py-3 rounded-xl bg-[#263F32] text-[#F8F4EA] text-sm font-medium hover:bg-[#1E3328] transition-colors cursor-pointer"
              >
                تکمیل خرید
              </button>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
