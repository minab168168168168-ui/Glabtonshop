import { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Minus,
  Plus,
  ShoppingBag,
  Tag,
  Trash2,
} from 'lucide-react';
import { PROVINCES } from '../data/catalog';
import { CartItem, OrderRecord, PageView, SavedAddress } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';

const FREE_SHIPPING_THRESHOLD = 1500000;
const BASE_SHIPPING_COST = 85000;

interface CartPageProps {
  items: CartItem[];
  discountCode: string;
  onApplyDiscount: (code: string) => void;
  onUpdateQty: (productId: string, variantId: string | undefined, delta: number) => void;
  onRemoveItem: (productId: string, variantId: string | undefined) => void;
  onNavigate: (page: PageView) => void;
}

export function CartPage({
  items,
  discountCode,
  onApplyDiscount,
  onUpdateQty,
  onRemoveItem,
  onNavigate,
}: CartPageProps) {
  const [codeInput, setCodeInput] = useState(discountCode);
  const [codeMessage, setCodeMessage] = useState('');

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmount = discountCode.toUpperCase() === 'GOLAB10' ? Math.round(subtotal * 0.1) : 0;
  const shippingCost = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : BASE_SHIPPING_COST;
  const total = Math.max(0, subtotal - discountAmount + shippingCost);

  const handleDiscountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = codeInput.trim().toUpperCase();
    if (!cleaned) {
      onApplyDiscount('');
      setCodeMessage('');
      return;
    }
    if (cleaned === 'GOLAB10') {
      onApplyDiscount('GOLAB10');
      setCodeMessage('کد تخفیف ۱۰٪ با موفقیت اعمال شد.');
    } else {
      setCodeMessage('کد تخفیف نامعتبر است. (برای تست از کد GOLAB10 استفاده کنید)');
    }
  };

  if (items.length === 0) {
    return (
      <div className="bg-persian-ivory">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-5">
          <div className="w-20 h-20 rounded-full bg-[#E6D2A5]/60 border border-[#D5A52E]/50 mx-auto flex items-center justify-center text-[#173D30]">
            <ShoppingBag className="w-9 h-9" strokeWidth={1.4} />
          </div>
          <h1 className="font-display-fa text-3xl text-[#173D30]">
            سبد خرید شما هنوز خالی است!
          </h1>
          <p className="text-sm text-[#60412E]/85">
            وقتشه طعم‌های خوش گلابتون رو کشف کنید.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('shop')}
            className="px-7 py-3 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold hover:bg-[#286044] transition-colors cursor-pointer"
          >
            مشاهده محصولات
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 pb-24 space-y-8">
        <div className="border-b border-[#D5A52E]/40 pb-5 flex items-center justify-between">
          <div>
            <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">سبد خرید شما</h1>
            <p className="text-xs text-[#176D79] font-medium mt-1 tabular-nums">
              {toPersianDigits(items.reduce((s, i) => s + i.quantity, 0))} قلم محصول انتخاب شده
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('shop')}
            className="text-xs sm:text-sm font-semibold text-[#173D30] hover:text-[#B51F2A] cursor-pointer"
          >
            ادامه خرید
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 space-y-4">
            {items.map((item) => (
              <div
                key={`${item.productId}-${item.variantId || 'default'}`}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 sm:p-5 bg-[#FBF6EB] border border-[#D5A52E]/40 rounded-2xl"
              >
                <div className="flex items-center gap-4 min-w-0">
                  <BrandImage
                    src={item.image}
                    alt={item.name}
                    className="w-24 h-20 rounded-xl shrink-0 border border-[#D5A52E]/30"
                  />
                  <div className="min-w-0 space-y-1">
                    <p className="text-xs text-[#176D79] font-medium">{item.categoryLabel}</p>
                    <h3 className="text-base font-bold text-[#173D30] truncate">{item.name}</h3>
                    <p className="text-xs text-[#60412E]/80">{item.variantLabel}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-5">
                  <div className="inline-flex items-center border border-[#D5A52E]/50 rounded-xl bg-[#F4E8D0]/60">
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.productId, item.variantId, 1)}
                      aria-label="افزایش تعداد"
                      className="w-9 h-9 flex items-center justify-center text-[#173D30] hover:bg-[#E6D2A5]/60 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-9 text-center text-sm font-bold text-[#173D30] tabular-nums">
                      {toPersianDigits(item.quantity)}
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.productId, item.variantId, -1)}
                      aria-label="کاهش تعداد"
                      className="w-9 h-9 flex items-center justify-center text-[#173D30] hover:bg-[#E6D2A5]/60 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="text-left min-w-[110px]">
                    <p className="text-base font-bold text-[#173D30] tabular-nums">
                      {formatToman(item.price * item.quantity)}
                    </p>
                    <p className="text-[11px] text-[#60412E]/75">تومان</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onRemoveItem(item.productId, item.variantId)}
                    aria-label="حذف از سبد"
                    className="p-2 rounded-lg text-[#60412E]/65 hover:text-[#B51F2A] hover:bg-[#F4E8D0] cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <aside className="lg:col-span-4 bg-[#FBF6EB] border border-[#D5A52E]/50 rounded-3xl p-6 space-y-5 sticky top-24 shadow-sm">
            <h2 className="text-lg font-bold text-[#173D30]">خلاصه سفارش</h2>

            <form onSubmit={handleDiscountSubmit} className="space-y-2">
              <label className="text-xs font-medium text-[#60412E] flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-[#176D79]" />
                <span>کد تخفیف (نمونه: GOLAB10)</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value)}
                  placeholder="کد را وارد کنید"
                  className="flex-1 h-10 px-3 rounded-xl bg-[#F4E8D0]/60 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
                />
                <button
                  type="submit"
                  className="px-4 h-10 rounded-xl border border-[#173D30] text-xs font-semibold text-[#173D30] hover:bg-[#173D30] hover:text-[#F4E8D0] transition-colors cursor-pointer"
                >
                  اعمال
                </button>
              </div>
              {codeMessage && (
                <p className="text-xs text-[#173D30] font-semibold">{codeMessage}</p>
              )}
            </form>

            <div className="pt-4 border-t border-[#D5A52E]/30 space-y-3 text-sm">
              <div className="flex justify-between text-[#60412E]">
                <span>جمع کل محصولات</span>
                <span className="tabular-nums font-medium">{formatToman(subtotal)} تومان</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-[#B51F2A] font-medium">
                  <span>تخفیف</span>
                  <span className="tabular-nums">-{formatToman(discountAmount)} تومان</span>
                </div>
              )}
              <div className="flex justify-between text-[#60412E]">
                <span>هزینه ارسال</span>
                <span className="tabular-nums font-medium">
                  {shippingCost === 0 ? 'رایگان' : `${formatToman(shippingCost)} تومان`}
                </span>
              </div>
              <div className="pt-3 border-t border-[#D5A52E]/40 flex justify-between items-baseline text-base font-bold text-[#173D30]">
                <span>مبلغ قابل پرداخت</span>
                <span className="text-lg tabular-nums">{formatToman(total)} تومان</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('checkout')}
              className="w-full py-3.5 rounded-xl bg-[#173D30] border border-[#D5A52E]/60 text-[#F4E8D0] text-sm font-bold hover:bg-[#286044] transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>تکمیل سفارش</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </aside>
        </div>
      </div>
    </div>
  );
}

interface CheckoutPageProps {
  items: CartItem[];
  discountCode: string;
  savedAddresses: SavedAddress[];
  onPlaceOrder: (order: OrderRecord) => void;
  onNavigate: (page: PageView) => void;
}

export function CheckoutPage({
  items,
  discountCode,
  savedAddresses,
  onPlaceOrder,
  onNavigate,
}: CheckoutPageProps) {
  const defaultAddr = savedAddresses[0];
  const [fullName, setFullName] = useState(defaultAddr?.recipient ?? '');
  const [mobile, setMobile] = useState(defaultAddr?.mobile ?? '');
  const [province, setProvince] = useState(defaultAddr?.province ?? 'تهران');
  const [city, setCity] = useState(defaultAddr?.city ?? 'تهران');
  const [address, setAddress] = useState(defaultAddr?.address ?? '');
  const [postalCode, setPostalCode] = useState(defaultAddr?.postalCode ?? '');
  const [notes, setNotes] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState('پست پیشتاز با بسته‌بندی ضدضربه');
  const [paymentMethod, setPaymentMethod] = useState('پرداخت در محل (ویژه پیش‌نمایش)');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmedOrder, setConfirmedOrder] = useState<OrderRecord | null>(null);

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmount = discountCode.toUpperCase() === 'GOLAB10' ? Math.round(subtotal * 0.1) : 0;
  const shippingCost = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : BASE_SHIPPING_COST;
  const total = Math.max(0, subtotal - discountAmount + shippingCost);

  if (confirmedOrder) {
    return (
      <div className="bg-persian-ivory">
        <div className="max-w-2xl mx-auto px-4 py-14 space-y-6">
          <div className="bg-[#FBF6EB] border-2 border-[#D5A52E]/55 rounded-3xl p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#173D30] border border-[#D5A52E]/60 text-[#F4E8D0] mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-[#D5A52E]" />
            </div>
            <h1 className="font-display-fa text-3xl text-[#173D30]">
              پیش‌نویس سفارش آماده اتصال به درگاه پرداخت
            </h1>
            <p className="text-sm text-[#60412E]">
              شناسه پیش‌نویس: <strong className="text-[#173D30] tabular-nums">{confirmedOrder.orderNumber}</strong>
            </p>
            <p className="text-xs text-[#B51F2A] leading-relaxed max-w-lg mx-auto">
              توجه: این محیط یک پیش‌نمایش رابط کاربری است و درگاه پرداخت بانکی یا سرور فروشگاه هنوز متصل نشده‌اند. هیچ پرداخت واقعی انجام نشده و این پیش‌نویس صرفاً برای بررسی جریان تسویه‌حساب در حافظه مرورگر ذخیره شده است.
            </p>

            <div className="bg-[#F4E8D0]/65 rounded-2xl p-5 text-right space-y-2.5 text-sm border border-[#D5A52E]/35 mt-4">
              <div className="flex justify-between">
                <span className="text-[#176D79]">تحویل‌گیرنده:</span>
                <span className="font-semibold text-[#173D30]">{confirmedOrder.recipientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#176D79]">روش ارسال:</span>
                <span className="text-[#173D30]">{confirmedOrder.deliveryMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#176D79]">روش پرداخت انتخاب‌شده:</span>
                <span className="text-[#173D30]">{confirmedOrder.paymentMethod}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#D5A52E]/25">
                <span className="text-[#176D79]">مبلغ پیش‌فاکتور:</span>
                <span className="font-bold text-[#173D30] tabular-nums">{formatToman(confirmedOrder.total)} تومان</span>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3 pt-4">
              <button
                type="button"
                onClick={() => onNavigate('account')}
                className="px-6 py-3 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold cursor-pointer"
              >
                مشاهده در تاریخچه پیش‌نویس حساب
              </button>
              <button
                type="button"
                onClick={() => onNavigate('shop')}
                className="px-6 py-3 rounded-xl border border-[#173D30] text-[#173D30] text-sm font-semibold cursor-pointer"
              >
                بازگشت به فروشگاه
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="bg-persian-ivory">
        <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-4">
          <h1 className="font-display-fa text-3xl text-[#173D30]">سبد خرید شما خالی است</h1>
          <p className="text-sm text-[#60412E]/85">برای تسویه‌حساب ابتدا محصولی به سبد اضافه کنید.</p>
          <button
            type="button"
            onClick={() => onNavigate('shop')}
            className="px-6 py-3 rounded-xl bg-[#173D30] text-[#F4E8D0] text-sm font-semibold cursor-pointer"
          >
            رفتن به فروشگاه
          </button>
        </div>
      </div>
    );
  }

  const validateAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (fullName.trim().length < 3) nextErrors.fullName = 'لطفاً نام و نام خانوادگی را کامل وارد کنید.';
    if (!/^09\d{9}$/.test(mobile.trim())) nextErrors.mobile = 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.';
    if (city.trim().length < 2) nextErrors.city = 'نام شهر را وارد کنید.';
    if (address.trim().length < 10) nextErrors.address = 'نشانی پستی کامل را وارد کنید.';
    if (!/^\d{10}$/.test(postalCode.trim())) nextErrors.postalCode = 'کد پستی باید دقیقاً ۱۰ رقم باشد.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const newOrder: OrderRecord = {
      id: `ord-${Date.now()}`,
      orderNumber: `GL-${toPersianDigits(Math.floor(100000 + Math.random() * 899999))}`,
      createdAt: 'امروز · ۱۴۰۵',
      status: 'در حال آماده‌سازی',
      items: [...items],
      subtotal,
      discount: discountAmount,
      shippingCost,
      total,
      recipientName: fullName.trim(),
      mobile: mobile.trim(),
      addressSummary: `${province}، ${city}، ${address.trim()}`,
      deliveryMethod,
      paymentMethod,
      notes: notes.trim() || undefined,
    };

    onPlaceOrder(newOrder);
    setConfirmedOrder(newOrder);
  };

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 pb-24">
        <div className="border-b border-[#D5A52E]/40 pb-5 mb-8">
          <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">تسویه‌حساب و ثبت سفارش</h1>
          <p className="text-sm text-[#60412E]/85 mt-1">اطلاعات ارسال و روش تحویل مرسوله را تکمیل کنید</p>
        </div>

        <form onSubmit={validateAndSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-6 bg-[#FBF6EB] border border-[#D5A52E]/45 rounded-3xl p-6 sm:p-8">
            <h2 className="text-lg font-bold text-[#173D30]">اطلاعات گیرنده</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">
                  نام و نام خانوادگی <span className="text-[#B51F2A]">*</span>
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="نام کامل گیرنده"
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
                />
                {errors.fullName && <p className="text-xs text-[#B51F2A]">{errors.fullName}</p>}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">
                  شماره موبایل <span className="text-[#B51F2A]">*</span>
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="09123456789"
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm text-right tabular-nums focus:outline-none focus:border-[#173D30]"
                />
                {errors.mobile && <p className="text-xs text-[#B51F2A]">{errors.mobile}</p>}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">
                  استان <span className="text-[#B51F2A]">*</span>
                </label>
                <select
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
                >
                  {PROVINCES.map((prov) => (
                    <option key={prov} value={prov}>
                      {prov}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">
                  شهر <span className="text-[#B51F2A]">*</span>
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="نام شهر"
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
                />
                {errors.city && <p className="text-xs text-[#B51F2A]">{errors.city}</p>}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#173D30]">
                نشانی کامل پستی <span className="text-[#B51F2A]">*</span>
              </label>
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="خیابان، کوچه، پلاک، واحد"
                className="w-full p-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
              />
              {errors.address && <p className="text-xs text-[#B51F2A]">{errors.address}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">
                  کد پستی ۱۰ رقمی <span className="text-[#B51F2A]">*</span>
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="1234567890"
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm text-right tabular-nums focus:outline-none focus:border-[#173D30]"
                />
                {errors.postalCode && <p className="text-xs text-[#B51F2A]">{errors.postalCode}</p>}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">یادداشت سفارش (اختیاری)</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="ساعت ترجیحی تحویل یا نکته بسته‌بندی"
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm focus:outline-none focus:border-[#173D30]"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-[#D5A52E]/30 space-y-3">
              <h3 className="text-sm font-bold text-[#173D30]">روش ارسال</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  'پست پیشتاز با بسته‌بندی ضدضربه',
                  'پیک ویژه گلابتون (محدوده تهران)',
                ].map((method) => (
                  <label
                    key={method}
                    className={`p-3.5 rounded-xl border text-xs sm:text-sm cursor-pointer flex items-center gap-2.5 ${
                      deliveryMethod === method
                        ? 'bg-[#173D30] text-[#F4E8D0] border-[#D5A52E]'
                        : 'bg-[#F4E8D0]/55 text-[#60412E] border-[#D5A52E]/40'
                    }`}
                  >
                    <input
                      type="radio"
                      name="delivery"
                      checked={deliveryMethod === method}
                      onChange={() => setDeliveryMethod(method)}
                      className="accent-[#D5A52E]"
                    />
                    <span>{method}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#D5A52E]/30 space-y-3">
              <h3 className="text-sm font-bold text-[#173D30]">روش پرداخت</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  'پرداخت در محل (ویژه پیش‌نمایش)',
                  'ثبت پیش‌نویس جهت هماهنگی کارت‌به‌کارت',
                ].map((method) => (
                  <label
                    key={method}
                    className={`p-3.5 rounded-xl border text-xs sm:text-sm cursor-pointer flex items-center gap-2.5 ${
                      paymentMethod === method
                        ? 'bg-[#173D30] text-[#F4E8D0] border-[#D5A52E]'
                        : 'bg-[#F4E8D0]/55 text-[#60412E] border-[#D5A52E]/40'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === method}
                      onChange={() => setPaymentMethod(method)}
                      className="accent-[#D5A52E]"
                    />
                    <span>{method}</span>
                  </label>
                ))}
              </div>
              <p className="text-[11px] text-[#176D79]">
                توجه: درگاه پرداخت بانکی آنلاین در این محیط پیش‌نمایش متصل نیست؛ ثبت سفارش به صورت پیش‌نویس آزمایشی ذخیره می‌شود.
              </p>
            </div>
          </div>

          <aside className="lg:col-span-5 bg-[#FBF6EB] border border-[#D5A52E]/50 rounded-3xl p-6 sm:p-8 space-y-5 sticky top-24 shadow-sm">
            <h2 className="text-lg font-bold text-[#173D30]">خلاصه سفارش شما</h2>

            <div className="space-y-3 max-h-72 overflow-y-auto pl-1">
              {items.map((item) => (
                <div
                  key={`${item.productId}-${item.variantId || 'default'}`}
                  className="flex items-center justify-between gap-3 text-sm pb-3 border-b border-[#D5A52E]/25"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-[#173D30] truncate">{item.name}</p>
                    <p className="text-xs text-[#176D79]">
                      {item.variantLabel} × {toPersianDigits(item.quantity)}
                    </p>
                  </div>
                  <span className="font-semibold text-[#173D30] tabular-nums whitespace-nowrap">
                    {formatToman(item.price * item.quantity)} تومان
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2.5 text-sm pt-2">
              <div className="flex justify-between text-[#60412E]">
                <span>جمع محصولات</span>
                <span className="tabular-nums">{formatToman(subtotal)} تومان</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-[#B51F2A] font-medium">
                  <span>تخفیف</span>
                  <span className="tabular-nums">-{formatToman(discountAmount)} تومان</span>
                </div>
              )}
              <div className="flex justify-between text-[#60412E]">
                <span>هزینه ارسال</span>
                <span className="tabular-nums">
                  {shippingCost === 0 ? 'رایگان' : `${formatToman(shippingCost)} تومان`}
                </span>
              </div>
              <div className="pt-3 border-t border-[#D5A52E]/35 flex justify-between items-baseline text-base font-bold text-[#173D30]">
                <span>مبلغ قابل پرداخت</span>
                <span className="text-xl tabular-nums">{formatToman(total)} تومان</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-[#173D30] border border-[#D5A52E]/70 text-[#F4E8D0] text-sm font-bold hover:bg-[#286044] transition-colors cursor-pointer"
            >
              ثبت و پرداخت سفارش
            </button>
          </aside>
        </form>
      </div>
    </div>
  );
}
