import { Instagram, Mail, MapPin, Phone } from 'lucide-react';
import { CATEGORIES } from '../data/catalog';
import { CategorySlug, PageView } from '../types/store';
import { OfficialLogo, PersianDivider } from './BrandMark';

interface FooterProps {
  onNavigate: (page: PageView, category?: CategorySlug) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-royal-persian text-[#F4E8D0] pt-16 pb-24 lg:pb-10 border-t-2 border-[#D5A52E]/55">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12">
          {/* Official Brand Logo & Headline */}
          <div className="lg:col-span-4 space-y-5">
            <div className="flex items-center gap-4">
              <OfficialLogo size="lg" />
              <div className="space-y-1">
                <p className="font-display-fa text-2xl text-[#F4E8D0]">گلابتون شاپ</p>
                <p className="text-xs font-semibold text-[#D5A52E]">
                  گلابتون شاپ؛ عطر اصالت، طعم خونه
                </p>
                <p className="font-latin-serif text-[11px] tracking-[0.22em] text-[#E6D2A5]/80 uppercase">
                  GOLABTOON SHOP
                </p>
              </div>
            </div>

            <p className="text-sm text-[#E6D2A5]/90 leading-relaxed max-w-sm">
              گلابتون شاپ؛ همراه سفره‌های گرم و طعم‌های اصیل ایرانی. مجموعه‌ای منتخب از عرقیجات گیاهی، ترشیجات خانگی، مربا و خوراکی‌های سنتی.
            </p>

            <div className="flex items-center gap-3 pt-1">
              <a
                href="#instagram"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('about');
                }}
                aria-label="صفحه اینستاگرام گلابتون شاپ"
                className="w-10 h-10 rounded-full border border-[#D5A52E]/50 flex items-center justify-center text-[#E6D2A5] hover:bg-[#D5A52E] hover:text-[#100D0B] transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={() => onNavigate('contact')}
                aria-label="ارسال ایمیل"
                className="w-10 h-10 rounded-full border border-[#D5A52E]/50 flex items-center justify-center text-[#E6D2A5] hover:bg-[#D5A52E] hover:text-[#100D0B] transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Column 1: Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h3 className="text-sm font-bold text-[#D5A52E]">دسترسی سریع</h3>
            <ul className="space-y-2.5 text-sm text-[#E6D2A5]/90">
              <li>
                <button type="button" onClick={() => onNavigate('home')} className="hover:text-[#F4E8D0] cursor-pointer">
                  صفحه اصلی
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('shop', 'all')} className="hover:text-[#F4E8D0] cursor-pointer">
                  فروشگاه
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('about')} className="hover:text-[#F4E8D0] cursor-pointer">
                  درباره ما
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('contact')} className="hover:text-[#F4E8D0] cursor-pointer">
                  تماس با ما
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('faq')} className="hover:text-[#F4E8D0] cursor-pointer">
                  سوالات متداول
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Categories */}
          <div className="lg:col-span-3 space-y-3">
            <h3 className="text-sm font-bold text-[#D5A52E]">دسته‌بندی محصولات</h3>
            <ul className="space-y-2.5 text-sm text-[#E6D2A5]/90">
              {CATEGORIES.map((cat) => (
                <li key={cat.slug}>
                  <button
                    type="button"
                    onClick={() => onNavigate('shop', cat.slug)}
                    className="hover:text-[#F4E8D0] cursor-pointer"
                  >
                    {cat.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact & Guide */}
          <div className="lg:col-span-3 space-y-3">
            <h3 className="text-sm font-bold text-[#D5A52E]">ارتباط با ما</h3>
            <ul className="space-y-3 text-sm text-[#E6D2A5]/90">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#D5A52E] mt-0.5 shrink-0" />
                <span className="tabular-nums">۰۲۱-۰۰۰۰۰۰۰۰ (قابل ویرایش)</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#D5A52E] mt-0.5 shrink-0" />
                <span>hello@golabtoonshop.example</span>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D5A52E] mt-0.5 shrink-0" />
                <span>تهران — نشانی قابل ویرایش</span>
              </li>
            </ul>
            <div className="pt-3 flex flex-wrap gap-2 text-xs text-[#E6D2A5]/75">
              <button type="button" onClick={() => onNavigate('faq')} className="underline underline-offset-4 hover:text-[#F4E8D0] cursor-pointer">
                نحوه ثبت سفارش
              </button>
              <span aria-hidden="true">·</span>
              <button type="button" onClick={() => onNavigate('account')} className="underline underline-offset-4 hover:text-[#F4E8D0] cursor-pointer">
                پیگیری سفارش
              </button>
            </div>
          </div>
        </div>

        <PersianDivider light />

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#E6D2A5]/75">
          <p>© ۱۴۰۵ گلابتون شاپ (GOLABTOON SHOP) — تمامی حقوق محفوظ است.</p>
          <div className="flex items-center gap-4">
            <span>جایگاه نماد اعتماد الکترونیکی</span>
            <span aria-hidden="true">·</span>
            <span>جایگاه نشان ساماندهی</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
