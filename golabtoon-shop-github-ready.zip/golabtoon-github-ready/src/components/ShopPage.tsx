import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../data/catalog';
import { CategorySlug, Product } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { ProductCard } from './ProductCard';

interface ShopPageProps {
  initialCategory: CategorySlug;
  wishlistIds: string[];
  onCategoryChange: (category: CategorySlug) => void;
  onSelectProduct: (productId: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
}

type SortOption = 'popular' | 'newest' | 'price-asc' | 'price-desc';

export function ShopPage({
  initialCategory,
  wishlistIds,
  onCategoryChange,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
}: ShopPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [maxPrice, setMaxPrice] = useState(400000);
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('popular');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(8);

  const filteredProducts = useMemo(() => {
    const query = searchTerm.trim();
    const list = PRODUCTS.filter((product) => {
      if (initialCategory !== 'all' && product.category !== initialCategory) return false;
      if (onlyAvailable && !product.inStock) return false;
      if (product.price > maxPrice) return false;
      if (
        query &&
        !product.name.includes(query) &&
        !product.categoryLabel.includes(query) &&
        !product.shortDescription.includes(query)
      ) {
        return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'newest') return Number(Boolean(b.isNew)) - Number(Boolean(a.isNew));
      return b.popularityScore - a.popularityScore;
    });
  }, [initialCategory, maxPrice, onlyAvailable, searchTerm, sortBy]);

  const visibleProducts = filteredProducts.slice(0, visibleCount);
  const activeCategoryLabel =
    initialCategory === 'all'
      ? 'همه محصولات'
      : CATEGORIES.find((c) => c.slug === initialCategory)?.title ?? 'فروشگاه';

  const resetFilters = () => {
    onCategoryChange('all');
    setSearchTerm('');
    setMaxPrice(400000);
    setOnlyAvailable(false);
    setSortBy('popular');
  };

  const FilterControls = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-bold text-[#173D30] mb-3">دسته‌بندی محصولات</h3>
        <div className="space-y-1.5">
          <button
            type="button"
            onClick={() => onCategoryChange('all')}
            className={`w-full text-right px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
              initialCategory === 'all'
                ? 'bg-[#173D30] text-[#F4E8D0] font-semibold border border-[#D5A52E]/45'
                : 'text-[#60412E] hover:bg-[#E6D2A5]/45'
            }`}
          >
            همه طعم‌ها ({toPersianDigits(PRODUCTS.length)})
          </button>
          {CATEGORIES.map((cat) => {
            const count = PRODUCTS.filter((p) => p.category === cat.slug).length;
            return (
              <button
                key={cat.slug}
                type="button"
                onClick={() => onCategoryChange(cat.slug)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                  initialCategory === cat.slug
                    ? 'bg-[#173D30] text-[#F4E8D0] font-semibold border border-[#D5A52E]/45'
                    : 'text-[#60412E] hover:bg-[#E6D2A5]/45'
                }`}
              >
                <span>{cat.title}</span>
                <span className="text-xs opacity-75 tabular-nums">{toPersianDigits(count)}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-5 border-t border-[#D5A52E]/30">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold text-[#173D30]">سقف قیمت</h3>
          <span className="text-xs font-semibold text-[#176D79] tabular-nums">
            تا {formatToman(maxPrice)} تومان
          </span>
        </div>
        <input
          type="range"
          min={150000}
          max={400000}
          step={15000}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-[#173D30] cursor-pointer"
        />
        <div className="flex justify-between text-[11px] text-[#60412E]/70 mt-1 tabular-nums">
          <span>۱۵۰٬۰۰۰</span>
          <span>۴۰۰٬۰۰۰ تومان</span>
        </div>
      </div>

      <div className="pt-5 border-t border-[#D5A52E]/30">
        <label className="flex items-center justify-between cursor-pointer select-none">
          <span className="text-sm font-medium text-[#173D30]">فقط کالاهای موجود</span>
          <input
            type="checkbox"
            checked={onlyAvailable}
            onChange={(e) => setOnlyAvailable(e.target.checked)}
            className="w-4 h-4 accent-[#173D30] rounded cursor-pointer"
          />
        </label>
      </div>

      <button
        type="button"
        onClick={resetFilters}
        className="w-full py-2.5 rounded-xl border border-[#D5A52E]/60 text-xs font-semibold text-[#173D30] hover:bg-[#E6D2A5]/40 transition-colors cursor-pointer"
      >
        پاک کردن فیلترها
      </button>
    </div>
  );

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 space-y-8 pb-24">
        <div className="border-b border-[#D5A52E]/40 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs text-[#176D79] font-medium mb-1.5">
              فروشگاه گلابتون شاپ / {activeCategoryLabel}
            </p>
            <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">
              فروشگاه گلابتون
            </h1>
            <p className="text-sm text-[#60412E]/85 mt-1">
              همه طعم‌های دوست‌داشتنی در یک جا
            </p>
          </div>
          <p className="text-xs font-medium text-[#176D79] tabular-nums">
            نمایش {toPersianDigits(visibleProducts.length)} از {toPersianDigits(filteredProducts.length)} محصول
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <aside className="hidden lg:block lg:col-span-3 bg-[#FBF6EB] border border-[#D5A52E]/45 rounded-2xl p-6 sticky top-24">
            <FilterControls />
          </aside>

          <div className="lg:col-span-9 space-y-6">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-[#FBF6EB] p-3.5 rounded-2xl border border-[#D5A52E]/40">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#176D79] absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="جستجو بین محصولات فروشگاه..."
                  className="w-full h-10 pr-10 pl-4 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm text-[#100D0B] placeholder:text-[#60412E]/55 focus:outline-none focus:border-[#173D30]"
                />
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setMobileFiltersOpen(true)}
                  className="lg:hidden h-10 px-4 rounded-xl bg-[#173D30] text-[#F4E8D0] border border-[#D5A52E]/50 text-xs font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  <span>فیلترها</span>
                </button>

                <select
                  aria-label="مرتب‌سازی محصولات"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="h-10 px-3 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-xs sm:text-sm font-medium text-[#173D30] focus:outline-none focus:border-[#173D30] cursor-pointer"
                >
                  <option value="popular">مرتب‌سازی: محبوب‌ترین</option>
                  <option value="newest">مرتب‌سازی: جدیدترین</option>
                  <option value="price-asc">ارزان‌ترین</option>
                  <option value="price-desc">گران‌ترین</option>
                </select>
              </div>
            </div>

            {visibleProducts.length === 0 ? (
              <div className="bg-[#FBF6EB] border border-[#D5A52E]/40 rounded-2xl p-12 text-center space-y-4">
                <p className="text-base font-bold text-[#173D30]">
                  محصولی مطابق با فیلترهای انتخابی یافت نشد.
                </p>
                <p className="text-sm text-[#60412E]/80">
                  می‌توانید سقف قیمت را افزایش دهید یا فیلترها را بازنشانی کنید.
                </p>
                <button
                  type="button"
                  onClick={resetFilters}
                  className="px-6 py-2.5 rounded-xl bg-[#173D30] text-[#F4E8D0] text-sm font-semibold cursor-pointer"
                >
                  نمایش همه محصولات
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                {visibleProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isWishlisted={wishlistIds.includes(product.id)}
                    onSelect={onSelectProduct}
                    onAddToCart={onAddToCart}
                    onToggleWishlist={onToggleWishlist}
                  />
                ))}
              </div>
            )}

            {visibleCount < filteredProducts.length && (
              <div className="pt-4 text-center">
                <button
                  type="button"
                  onClick={() => setVisibleCount((prev) => prev + 6)}
                  className="px-8 py-3 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-sm font-semibold text-[#F4E8D0] hover:bg-[#286044] transition-colors cursor-pointer"
                >
                  بارگذاری محصولات بیشتر
                </button>
              </div>
            )}
          </div>
        </div>

        {mobileFiltersOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-[#100D0B]/60 backdrop-blur-xs"
              onClick={() => setMobileFiltersOpen(false)}
            />
            <aside className="relative z-10 w-80 max-w-[85vw] bg-[#F7EFE0] h-full p-6 overflow-y-auto shadow-2xl border-l border-[#D5A52E]/50">
              <div className="flex items-center justify-between pb-4 mb-5 border-b border-[#D5A52E]/35">
                <h2 className="text-base font-bold text-[#173D30]">فیلتر محصولات</h2>
                <button
                  type="button"
                  onClick={() => setMobileFiltersOpen(false)}
                  className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-[#E6D2A5]/45 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <FilterControls />
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
