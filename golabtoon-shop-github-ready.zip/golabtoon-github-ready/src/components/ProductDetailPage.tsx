import { useState } from 'react';
import {
  Check,
  Heart,
  Minus,
  Plus,
  ShieldCheck,
  ShoppingBag,
  Truck,
  ZoomIn,
} from 'lucide-react';
import { PRODUCTS, SAMPLE_REVIEWS } from '../data/catalog';
import { CategorySlug, PageView, Product, ProductReview } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';
import { ProductCard } from './ProductCard';

interface ProductDetailPageProps {
  product: Product;
  wishlistIds: string[];
  recentlyViewedIds: string[];
  onNavigate: (page: PageView, category?: CategorySlug) => void;
  onSelectProduct: (productId: string) => void;
  onAddToCart: (
    product: Product,
    quantity: number,
    variantId?: string,
    variantLabel?: string,
    price?: number
  ) => void;
  onToggleWishlist: (productId: string) => void;
}

type DetailTab = 'intro' | 'ingredients' | 'specs' | 'storage' | 'reviews';

export function ProductDetailPage({
  product,
  wishlistIds,
  recentlyViewedIds,
  onNavigate,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
}: ProductDetailPageProps) {
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [selectedVariantId, setSelectedVariantId] = useState(
    product.variants?.[product.variants.length - 1]?.id
  );
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<DetailTab>('intro');
  const [justAdded, setJustAdded] = useState(false);

  const [reviews, setReviews] = useState<ProductReview[]>(SAMPLE_REVIEWS);
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [reviewSaved, setReviewSaved] = useState(false);

  const activeVariant = product.variants?.find((v) => v.id === selectedVariantId);
  const effectivePrice = activeVariant ? activeVariant.price : product.price;
  const effectiveWeight = activeVariant ? activeVariant.label : product.weight;
  const isWishlisted = wishlistIds.includes(product.id);

  const relatedProducts = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 4);

  const recentProducts = recentlyViewedIds
    .filter((id) => id !== product.id)
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p))
    .slice(0, 4);

  const handleAdd = () => {
    if (!product.inStock) return;
    onAddToCart(product, quantity, activeVariant?.id, effectiveWeight, effectivePrice);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1400);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewAuthor.trim() || !reviewText.trim()) return;
    const newRev: ProductReview = {
      id: `user-rev-${Date.now()}`,
      author: reviewAuthor.trim(),
      city: 'ثبت‌شده توسط کاربر',
      date: 'امروز',
      rating: 5,
      comment: reviewText.trim(),
    };
    setReviews((prev) => [newRev, ...prev]);
    setReviewAuthor('');
    setReviewText('');
    setReviewSaved(true);
    window.setTimeout(() => setReviewSaved(false), 2500);
  };

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-16 pb-32">
        {/* Breadcrumb */}
        <nav aria-label="مسیر صفحه" className="flex flex-wrap items-center gap-2 text-xs text-[#176D79] font-medium">
          <button type="button" onClick={() => onNavigate('home')} className="hover:text-[#173D30] cursor-pointer">
            خانه
          </button>
          <span aria-hidden="true">/</span>
          <button type="button" onClick={() => onNavigate('shop', 'all')} className="hover:text-[#173D30] cursor-pointer">
            فروشگاه
          </button>
          <span aria-hidden="true">/</span>
          <button
            type="button"
            onClick={() => onNavigate('shop', product.category)}
            className="hover:text-[#173D30] cursor-pointer"
          >
            {product.categoryLabel}
          </button>
          <span aria-hidden="true">/</span>
          <span className="text-[#173D30] font-bold">{product.name}</span>
        </nav>

        {/* Gallery (Right) + Sticky Purchase Module (Left) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          <div className="lg:col-span-6 space-y-4 lg:sticky lg:top-24">
            <div
              onClick={() => setIsZoomed((z) => !z)}
              className="relative aspect-[4/3] rounded-3xl overflow-hidden bg-[#E6D2A5]/45 border-2 border-[#D5A52E]/55 cursor-zoom-in group shadow-md"
            >
              <BrandImage
                src={product.gallery[activeImageIdx] ?? product.image}
                alt={product.name}
                loading="eager"
                className={`w-full h-full transition-transform duration-300 ${
                  isZoomed ? 'scale-125' : 'group-hover:scale-[1.02]'
                }`}
              />
              <span className="absolute bottom-3 left-3 w-9 h-9 rounded-full bg-[#173D30] text-[#F4E8D0] border border-[#D5A52E]/60 flex items-center justify-center shadow-sm">
                <ZoomIn className="w-4 h-4" />
              </span>
            </div>

            {product.gallery.length > 1 && (
              <div className="grid grid-cols-4 gap-3">
                {product.gallery.map((img, idx) => (
                  <button
                    key={`${img}-${idx}`}
                    type="button"
                    onClick={() => {
                      setActiveImageIdx(idx);
                      setIsZoomed(false);
                    }}
                    className={`aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                      activeImageIdx === idx
                        ? 'border-[#173D30] ring-2 ring-[#D5A52E]/60'
                        : 'border-[#D5A52E]/35 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <BrandImage
                      src={img}
                      alt={`${product.name} تصویر ${toPersianDigits(idx + 1)}`}
                      className="w-full h-full"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="lg:col-span-6 bg-[#FBF6EB] border border-[#D5A52E]/50 rounded-3xl p-6 sm:p-8 space-y-6 lg:sticky lg:top-24 shadow-sm">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between gap-2 text-xs font-semibold">
                <span className="text-[#176D79]">{product.categoryLabel}</span>
                <span className={product.inStock ? 'text-[#286044]' : 'text-[#B51F2A]'}>
                  {product.inStock ? 'موجود و آماده ارسال' : 'ناموجود موقت'}
                </span>
              </div>
              <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">
                {product.name}
              </h1>
              <p className="text-sm sm:text-base text-[#60412E] leading-relaxed">
                {product.shortDescription}
              </p>
            </div>

            <div className="pt-4 border-t border-[#D5A52E]/30 flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-bold text-[#173D30] tabular-nums">
                {formatToman(effectivePrice)}
              </span>
              <span className="text-sm text-[#60412E]/80">تومان</span>
            </div>

            {product.variants && product.variants.length > 0 ? (
              <div className="space-y-2.5">
                <p className="text-xs font-bold text-[#173D30]">انتخاب وزن / حجم:</p>
                <div className="flex flex-wrap gap-2.5">
                  {product.variants.map((variant) => (
                    <button
                      key={variant.id}
                      type="button"
                      onClick={() => setSelectedVariantId(variant.id)}
                      className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium border transition-colors cursor-pointer ${
                        activeVariant?.id === variant.id
                          ? 'bg-[#173D30] text-[#F4E8D0] border-[#D5A52E]'
                          : 'bg-[#F4E8D0]/60 text-[#60412E] border-[#D5A52E]/40 hover:border-[#173D30]'
                      }`}
                    >
                      {variant.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-xs text-[#60412E]">
                وزن / حجم بسته: <strong className="text-[#173D30]">{product.weight}</strong>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <div className="inline-flex items-center justify-between border border-[#D5A52E]/50 rounded-xl bg-[#F4E8D0]/55 px-2 h-12 sm:w-36">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  aria-label="افزایش تعداد"
                  className="w-9 h-9 flex items-center justify-center text-[#173D30] hover:bg-[#E6D2A5]/60 rounded-lg cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <span className="text-sm font-bold text-[#173D30] tabular-nums">
                  {toPersianDigits(quantity)}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  aria-label="کاهش تعداد"
                  className="w-9 h-9 flex items-center justify-center text-[#173D30] hover:bg-[#E6D2A5]/60 rounded-lg cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                disabled={!product.inStock}
                onClick={handleAdd}
                className={`flex-1 h-12 px-6 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
                  !product.inStock
                    ? 'bg-[#E6D2A5]/60 border-[#B88B37]/30 text-[#60412E]/50 cursor-not-allowed'
                    : justAdded
                    ? 'bg-[#286044] border-[#D5A52E] text-[#F4E8D0]'
                    : 'bg-[#173D30] border-[#D5A52E]/60 text-[#F4E8D0] hover:bg-[#286044]'
                }`}
              >
                {justAdded ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>به سبد خرید اضافه شد</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>{product.inStock ? 'افزودن به سبد خرید' : 'فعلاً ناموجود'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => onToggleWishlist(product.id)}
                aria-label="افزودن به علاقه‌مندی‌ها"
                className={`h-12 w-12 rounded-xl border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                  isWishlisted
                    ? 'bg-[#B51F2A] border-[#D5A52E]/60 text-[#F4E8D0]'
                    : 'bg-[#F4E8D0]/55 border-[#D5A52E]/50 text-[#60412E] hover:text-[#B51F2A]'
                }`}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            <div className="pt-4 border-t border-[#D5A52E]/30 space-y-2.5 text-xs text-[#60412E]">
              <div className="flex items-center gap-2.5">
                <Truck className="w-4 h-4 text-[#176D79] shrink-0" />
                <span>ارسال ایمن به سراسر کشور (ارسال رایگان بالای ۱٬۵۰۰٬۰۰۰ تومان)</span>
              </div>
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#176D79] shrink-0" />
                <span>{product.packagingNote}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 5 Information Tabs */}
        <section className="bg-[#FBF6EB] border border-[#D5A52E]/45 rounded-3xl overflow-hidden">
          <div className="flex overflow-x-auto border-b border-[#D5A52E]/30 bg-[#E6D2A5]/35">
            {[
              { id: 'intro' as DetailTab, label: 'معرفی محصول' },
              { id: 'ingredients' as DetailTab, label: 'ترکیبات' },
              { id: 'specs' as DetailTab, label: 'مشخصات محصول' },
              { id: 'storage' as DetailTab, label: 'شرایط نگهداری' },
              { id: 'reviews' as DetailTab, label: `نظرات مشتریان (${toPersianDigits(reviews.length)})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'border-[#173D30] text-[#173D30] font-bold bg-[#FBF6EB]'
                    : 'border-transparent text-[#60412E]/80 hover:text-[#173D30]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="p-6 sm:p-8">
            {activeTab === 'intro' && (
              <div className="max-w-3xl space-y-3 text-sm sm:text-base text-[#60412E] leading-loose">
                <p>{product.fullDescription}</p>
                <p className="text-xs text-[#176D79]">
                  توضیحات این بخش قابل ویرایش و سفارشی‌سازی با جزئیات سری ساخت شما است.
                </p>
              </div>
            )}

            {activeTab === 'ingredients' && (
              <ul className="space-y-2.5 text-sm text-[#60412E] list-disc list-inside">
                {product.ingredients.map((ing) => (
                  <li key={ing}>{ing}</li>
                ))}
              </ul>
            )}

            {activeTab === 'specs' && (
              <div className="max-w-2xl divide-y divide-[#D5A52E]/25">
                {product.specifications.map((spec) => (
                  <div key={spec.label} className="py-3 flex items-center justify-between gap-4 text-sm">
                    <span className="text-[#176D79] font-medium">{spec.label}</span>
                    <span className="font-semibold text-[#173D30]">{spec.value}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'storage' && (
              <p className="max-w-3xl text-sm sm:text-base text-[#60412E] leading-loose">
                {product.storageInstructions}
              </p>
            )}

            {activeTab === 'reviews' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-7 space-y-4">
                  {reviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-4 rounded-2xl bg-[#F4E8D0]/55 border border-[#D5A52E]/30 space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs text-[#176D79]">
                        <span className="font-semibold text-[#173D30]">{rev.author}</span>
                        <span>{rev.date}</span>
                      </div>
                      <p className="text-sm text-[#60412E] leading-relaxed">{rev.comment}</p>
                    </div>
                  ))}
                </div>

                <form
                  onSubmit={handleReviewSubmit}
                  className="lg:col-span-5 bg-[#F4E8D0]/65 border border-[#D5A52E]/40 rounded-2xl p-5 space-y-4 h-fit"
                >
                  <h3 className="text-sm font-bold text-[#173D30]">ثبت دیدگاه شما</h3>
                  <input
                    type="text"
                    value={reviewAuthor}
                    onChange={(e) => setReviewAuthor(e.target.value)}
                    placeholder="نام شما"
                    required
                    className="w-full h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
                  />
                  <textarea
                    rows={3}
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder="تجربه خود از طعم و بسته‌بندی این محصول را بنویسید..."
                    required
                    className="w-full p-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
                  />
                  <button
                    type="submit"
                    className="w-full h-10 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold hover:bg-[#286044] transition-colors cursor-pointer"
                  >
                    ارسال دیدگاه
                  </button>
                  {reviewSaved && (
                    <p className="text-xs text-[#173D30] font-semibold">
                      دیدگاه شما با موفقیت به فهرست اضافه شد.
                    </p>
                  )}
                </form>
              </div>
            )}
          </div>
        </section>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="space-y-6">
            <h2 className="font-display-fa text-2xl sm:text-3xl text-[#173D30]">
              محصولات مرتبط از همین خانواده
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {relatedProducts.map((rel) => (
                <ProductCard
                  key={rel.id}
                  product={rel}
                  isWishlisted={wishlistIds.includes(rel.id)}
                  onSelect={onSelectProduct}
                  onAddToCart={(p) => onAddToCart(p, 1)}
                  onToggleWishlist={onToggleWishlist}
                />
              ))}
            </div>
          </section>
        )}

        {/* Recently Viewed */}
        {recentProducts.length > 0 && (
          <section className="space-y-6 pb-10 lg:pb-0">
            <h2 className="font-display-fa text-2xl text-[#173D30]">
              بازدیدهای اخیر شما
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {recentProducts.map((rec) => (
                <ProductCard
                  key={rec.id}
                  product={rec}
                  isWishlisted={wishlistIds.includes(rec.id)}
                  onSelect={onSelectProduct}
                  onAddToCart={(p) => onAddToCart(p, 1)}
                  onToggleWishlist={onToggleWishlist}
                />
              ))}
            </div>
          </section>
        )}

        {/* Sticky Add-to-Cart Bar on Mobile */}
        <div className="lg:hidden fixed bottom-14 inset-x-0 z-30 bg-[#F7EFE0]/98 backdrop-blur-md border-t border-[#D5A52E]/55 px-4 py-2.5 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-bold text-[#173D30] truncate">{product.name}</p>
            <p className="text-xs font-semibold text-[#176D79] tabular-nums">
              {formatToman(effectivePrice)} تومان
            </p>
          </div>
          <button
            type="button"
            disabled={!product.inStock}
            onClick={handleAdd}
            className={`h-10 px-5 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer border ${
              !product.inStock
                ? 'bg-[#E6D2A5] border-[#B88B37]/30 text-[#60412E]/50 cursor-not-allowed'
                : justAdded
                ? 'bg-[#286044] border-[#D5A52E] text-[#F4E8D0]'
                : 'bg-[#173D30] border-[#D5A52E]/60 text-[#F4E8D0]'
            }`}
          >
            {justAdded ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
            <span>{product.inStock ? (justAdded ? 'افزوده شد' : 'افزودن به سبد خرید') : 'ناموجود'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
