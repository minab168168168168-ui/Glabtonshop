import { useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  Clock,
  Instagram,
  Mail,
  MapPin,
  Phone,
  X,
} from 'lucide-react';
import { CATEGORIES, FAQ_ITEMS } from '../data/catalog';
import { CategorySlug, PageView, RecipeArticle } from '../types/store';
import { IMAGE_ASSETS } from '../utils/format';
import { BrandImage } from './BrandImage';
import { OfficialLogo, PersianDivider } from './BrandMark';

export function AboutPage({ onNavigate }: { onNavigate: (page: PageView, category?: CategorySlug) => void }) {
  const scrollToStory = () => {
    const el = document.getElementById('golabtoon-story');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-persian-ivory pb-24 space-y-20 md:space-y-24">
      {/* 1. BACKGROUND D: ROSE GARDEN CINEMATIC HERO */}
      <section className="relative bg-rose-garden min-h-[440px] sm:min-h-[520px] flex items-center overflow-hidden border-b-2 border-[#D5A52E]/55">
        <BrandImage
          src={IMAGE_ASSETS.brandStory}
          alt="آشپزخانه سنتی ایرانی با شیشه‌های مربا، ترشی و گلبرگ‌های گل محمدی"
          loading="eager"
          className="absolute inset-0 w-full h-full opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-[#100D0B]/88 via-[#173D30]/82 to-[#173D30]/55" />
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
          <div className="max-w-2xl space-y-6 text-[#F4E8D0]">
            <div className="flex items-center gap-4">
              <OfficialLogo size="lg" />
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#D5A52E]">عطر اصالت، طعم خونه</p>
                <p className="font-latin-serif text-xs tracking-[0.22em] text-[#E6D2A5] uppercase">
                  GOLABTOON SHOP
                </p>
              </div>
            </div>
            <h1 className="font-display-fa text-4xl sm:text-5xl lg:text-[3.25rem] leading-[1.3]">
              گلابتون؛ روایت اصالت، هنر و طعم‌های ماندگار
            </h1>
            <p className="text-base sm:text-lg text-[#E6D2A5]/90 leading-relaxed">
              بعضی طعم‌ها فقط یک مزه نیستند؛ خاطره‌ای هستند که همیشه در دل ما زنده می‌مانند.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={scrollToStory}
                className="px-7 py-3.5 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-bold hover:bg-[#E6D2A5] transition-colors cursor-pointer"
              >
                با داستان ما آشنا شوید
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. The Story Behind Golabtoon */}
      <section id="golabtoon-story" className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-semibold text-[#B51F2A]">از عشق به طعم‌های اصیل</p>
            <h2 className="font-display-fa text-3xl sm:text-4xl text-[#173D30] leading-snug">
              هر طعم، قصه‌ای از خانه و خاطره
            </h2>
            <p className="text-base text-[#60412E] leading-loose">
              گلابتون شاپ با الهام از زیبایی فرهنگ غذایی ایران و عشق به طعم‌های اصیل شکل گرفته است. ما به زیبایی لحظه‌های ساده، عطر گیاهان خوشبو و لذت خوراکی‌های دوست‌داشتنی ایرانی باور داریم.
            </p>
            <p className="text-xs text-[#176D79]">
              اطلاعات تکمیلی و تاریخچه اختصاصی مجموعه شما در این بخش به سادگی قابل ویرایش است.
            </p>
          </div>
          <div className="lg:col-span-6">
            <div className="p-2.5 rounded-3xl border border-[#D5A52E]/55 bg-[#173D30] shadow-xl">
              <div className="aspect-[16/10] rounded-2xl overflow-hidden">
                <BrandImage
                  src={IMAGE_ASSETS.heroTable}
                  alt="آماده‌سازی خوراکی‌های سنتی و خانگی روی میز چوبی"
                  className="w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Four Visual Brand Pillars */}
      <section className="bg-royal-tilework text-[#F4E8D0] border-y-2 border-[#D5A52E]/45 py-16">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <PersianDivider light />
            <h2 className="font-display-fa text-3xl sm:text-4xl">
              ما به سادگیِ طعم‌های اصیل باور داریم
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                num: '۰۱',
                title: 'اصالت ایرانی',
                desc: 'الهام‌گرفته از فرهنگ، هنر و ذائقه اصیل ایرانی.',
              },
              {
                num: '۰۲',
                title: 'توجه به کیفیت',
                desc: 'دقت در انتخاب مواد اولیه تازه و جزئیات آماده‌سازی.',
              },
              {
                num: '۰۳',
                title: 'عشق به طعم‌های خانگی',
                desc: 'اهمیت دادن به حس گرم، صمیمی و خاطره‌انگیز خوراکی‌های خانگی.',
              },
              {
                num: '۰۴',
                title: 'زیبایی در جزئیات',
                desc: 'احترام به هنر بسته‌بندی شیشه‌ای و تجربه خرید دلنشین.',
              },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-[#100D0B]/55 border border-[#D5A52E]/45 rounded-2xl p-6 space-y-2.5"
              >
                <span className="text-xs font-bold text-[#D5A52E] tabular-nums">{item.num}</span>
                <h3 className="text-lg font-bold text-[#F4E8D0]">{item.title}</h3>
                <p className="text-sm text-[#E6D2A5]/85 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Our Product World */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <p className="text-xs font-semibold text-[#176D79]">دنیای محصولات گلابتون</p>
          <h2 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">
            گنجینه‌ای از طعم‌های خانگی و سنتی
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.slug}
              type="button"
              onClick={() => onNavigate('shop', cat.slug)}
              className="group relative aspect-[4/3] rounded-t-[3rem] rounded-b-2xl overflow-hidden border border-[#D5A52E]/50 text-right cursor-pointer"
            >
              <BrandImage
                src={cat.image}
                alt={cat.title}
                className="w-full h-full transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#100D0B]/90 via-[#173D30]/30 to-transparent" />
              <div className="absolute bottom-4 right-4 left-4 text-[#F4E8D0]">
                <p className="text-sm sm:text-base font-bold text-[#D5A52E]">{cat.title}</p>
                <p className="text-xs text-[#E6D2A5]/90 mt-0.5 line-clamp-1">{cat.description}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* 5. Closing Luxurious Section */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-royal-persian text-[#F4E8D0] border-2 border-[#D5A52E]/55 rounded-3xl p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-5">
            <OfficialLogo size="md" />
            <h2 className="font-display-fa text-3xl sm:text-4xl text-[#F4E8D0]">
              گلابتون، همراه سفره‌های گرم شما
            </h2>
            <p className="text-base text-[#E6D2A5]/90 leading-loose">
              خوشحالیم که بخشی از لحظه‌های خوش و سفره‌های گرم شما هستیم. امیدواریم هر انتخاب از گلابتون، یادآور طعم‌های دوست‌داشتنی و حس خوب خانه باشد.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                type="button"
                onClick={() => onNavigate('shop', 'all')}
                className="px-7 py-3 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-bold hover:bg-[#E6D2A5] transition-colors cursor-pointer"
              >
                مشاهده محصولات
              </button>
              <button
                type="button"
                onClick={() => onNavigate('contact')}
                className="px-6 py-3 rounded-xl border border-[#D5A52E]/65 text-[#F4E8D0] text-sm font-semibold hover:bg-[#D5A52E]/15 transition-colors cursor-pointer"
              >
                ارتباط با ما
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-[#D5A52E]/50">
              <BrandImage
                src={IMAGE_ASSETS.jams}
                alt="شیشه‌های مربا و رب انار گلابتون شاپ"
                className="w-full h-full"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;
    setSubmitted(true);
    setName('');
    setPhone('');
    setEmail('');
    setSubject('');
    setMessage('');
  };

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 pb-24 space-y-12">
        <div className="border-b border-[#D5A52E]/35 pb-6">
          <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">تماس با گلابتون شاپ</h1>
          <p className="text-sm text-[#60412E]/85 mt-1.5">
            برای سفارش‌های مناسبتی، همکاری یا پرسش درباره محصولات با ما در ارتباط باشید
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-5 bg-royal-persian text-[#F4E8D0] border border-[#D5A52E]/50 rounded-3xl p-7 sm:p-8 space-y-6">
            <h2 className="text-xl font-bold text-[#D5A52E]">اطلاعات تماس (قابل ویرایش)</h2>
            <div className="space-y-4 text-sm text-[#E6D2A5]/90">
              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#D5A52E] mt-1 shrink-0" />
                <div>
                  <p className="font-semibold text-[#F4E8D0]">شماره تماس</p>
                  <p className="tabular-nums mt-0.5">۰۲۱-۰۰۰۰۰۰۰۰</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[#D5A52E] mt-1 shrink-0" />
                <div>
                  <p className="font-semibold text-[#F4E8D0]">پست الکترونیک</p>
                  <p className="mt-0.5">hello@golabtoonshop.example</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#D5A52E] mt-1 shrink-0" />
                <div>
                  <p className="font-semibold text-[#F4E8D0]">نشانی</p>
                  <p className="mt-0.5">تهران — نشانی قابل ویرایش توسط مدیر فروشگاه</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#D5A52E] mt-1 shrink-0" />
                <div>
                  <p className="font-semibold text-[#F4E8D0]">ساعات پاسخگویی</p>
                  <p className="mt-0.5">شنبه تا پنج‌شنبه، ۹ صبح تا ۶ عصر (قابل ویرایش)</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Instagram className="w-4 h-4 text-[#D5A52E] mt-1 shrink-0" />
                <div>
                  <p className="font-semibold text-[#F4E8D0]">اینستاگرام</p>
                  <p className="mt-0.5" dir="ltr">@golabtoon.shop</p>
                </div>
              </div>
            </div>
          </div>

          <form
            onSubmit={handleSubmit}
            className="lg:col-span-7 bg-[#FBF6EB] border border-[#D5A52E]/45 rounded-3xl p-7 sm:p-8 space-y-4"
          >
            <h2 className="text-xl font-bold text-[#173D30]">ارسال پیام مستقیم</h2>

            {submitted && (
              <div className="p-4 rounded-xl bg-[#173D30] text-[#F4E8D0] text-sm flex items-center gap-2 border border-[#D5A52E]/40">
                <CheckCircle2 className="w-4 h-4 text-[#D5A52E]" />
                <span>پیام شما ثبت شد. همکاران ما در اولین فرصت با شما تماس می‌گیرند.</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="نام و نام خانوادگی *"
                required
                className="h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
              />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="شماره تماس"
                className="h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ایمیل"
                className="h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
              />
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="موضوع پیام"
                className="h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
              />
            </div>

            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="متن پیام شما *"
              required
              className="w-full p-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/40 text-sm focus:outline-none focus:border-[#173D30]"
            />

            <button
              type="submit"
              className="px-8 py-3 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold hover:bg-[#286044] transition-colors cursor-pointer"
            >
              ارسال پیام
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export function FaqPage({ onNavigate }: { onNavigate: (page: PageView) => void }) {
  const [openId, setOpenId] = useState<string | null>(FAQ_ITEMS[0].id);

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 md:py-16 pb-24 space-y-10">
        <div className="text-center space-y-2">
          <PersianDivider />
          <h1 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">سوالات متداول</h1>
          <p className="text-sm text-[#60412E]/85">
            پاسخ پرسش‌های رایج درباره ثبت سفارش، بسته‌بندی، ارسال و نگهداری محصولات
          </p>
        </div>

        <div className="space-y-3">
          {FAQ_ITEMS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                className="bg-[#FBF6EB] border border-[#D5A52E]/40 rounded-2xl overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? null : item.id)}
                  className="w-full px-5 py-4 text-right flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div>
                    <span className="text-[11px] text-[#176D79] font-medium block mb-0.5">
                      {item.group}
                    </span>
                    <span className="text-sm sm:text-base font-bold text-[#173D30]">
                      {item.question}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-[#173D30] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-2 text-sm text-[#60412E] leading-relaxed border-t border-[#D5A52E]/20">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="text-center pt-4 space-y-3">
          <p className="text-sm text-[#60412E]/85">پاسخ سوال خود را پیدا نکردید؟</p>
          <button
            type="button"
            onClick={() => onNavigate('contact')}
            className="px-6 py-2.5 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold hover:bg-[#286044] transition-colors cursor-pointer"
          >
            ارتباط با پشتیبانی
          </button>
        </div>
      </div>
    </div>
  );
}

export function RecipeModal({
  recipe,
  onClose,
  onExploreCategory,
}: {
  recipe: RecipeArticle | null;
  onClose: () => void;
  onExploreCategory: (cat: CategorySlug) => void;
}) {
  if (!recipe) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="fixed inset-0 bg-[#100D0B]/70 backdrop-blur-xs" onClick={onClose} />
      <article className="relative z-10 w-full max-w-2xl max-h-[85vh] overflow-y-auto bg-[#F7EFE0] border-2 border-[#D5A52E]/60 rounded-3xl shadow-2xl">
        <div className="relative aspect-[16/9]">
          <BrandImage src={recipe.image} alt={recipe.title} className="w-full h-full" />
          <button
            type="button"
            onClick={onClose}
            aria-label="بستن مطلب"
            className="absolute top-4 left-4 w-10 h-10 rounded-full bg-[#173D30] text-[#F4E8D0] border border-[#D5A52E]/60 flex items-center justify-center shadow-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          <div>
            <p className="text-xs text-[#176D79] font-medium mb-1.5">
              {recipe.category} · {recipe.readingTime}
            </p>
            <h2 className="font-display-fa text-2xl sm:text-3xl text-[#173D30]">
              {recipe.title}
            </h2>
          </div>

          <p className="text-sm sm:text-base text-[#60412E] leading-relaxed">
            {recipe.excerpt}
          </p>

          <div className="space-y-2">
            <h3 className="text-sm font-bold text-[#173D30]">مواد پیشنهادی:</h3>
            <ul className="list-disc list-inside space-y-1.5 text-sm text-[#60412E]">
              {recipe.ingredients.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-bold text-[#173D30]">نکات سرو و آماده‌سازی:</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm text-[#60412E] leading-relaxed">
              {recipe.steps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
          </div>

          <div className="pt-3 border-t border-[#D5A52E]/30 flex justify-end">
            <button
              type="button"
              onClick={() => {
                onExploreCategory(recipe.relatedCategory);
                onClose();
              }}
              className="px-6 py-2.5 rounded-xl bg-[#173D30] border border-[#D5A52E]/50 text-[#F4E8D0] text-sm font-semibold cursor-pointer"
            >
              مشاهده محصولات مرتبط
            </button>
          </div>
        </div>
      </article>
    </div>
  );
}
