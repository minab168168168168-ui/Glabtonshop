import { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Flower2,
  HeartHandshake,
  Instagram,
  PackageCheck,
  ShieldCheck,
  Sparkles,
  Star,
} from 'lucide-react';
import { CATEGORIES, PRODUCTS, RECIPES, SAMPLE_REVIEWS } from '../data/catalog';
import { CategorySlug, PageView, Product, RecipeArticle } from '../types/store';
import { IMAGE_ASSETS, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';
import { OfficialLogo, PersianDivider, RoyalCornerOrnament } from './BrandMark';
import { ProductCard } from './ProductCard';

interface HomePageProps {
  wishlistIds: string[];
  onNavigate: (page: PageView, category?: CategorySlug) => void;
  onSelectProduct: (productId: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  onOpenRecipe: (recipe: RecipeArticle) => void;
}

const SEASONAL_ITEMS = [
  {
    season: 'بهار',
    title: 'محصولات بهاری',
    description: 'نوبرانه‌های معطر بهاری و شکوفه‌های تازه باغی',
    image: IMAGE_ASSETS.heroTable,
    category: 'distillates' as CategorySlug,
  },
  {
    season: 'تقطیر سنتی',
    title: 'عرقیجات گیاهی',
    description: 'تقطیر آرام نعنا، بیدمشک و بهارنارنج معطر',
    image: IMAGE_ASSETS.distillates,
    category: 'distillates' as CategorySlug,
  },
  {
    season: 'تابستان',
    title: 'شربت‌های تابستانی',
    description: 'پذیرایی خنک و دلپذیر با گل محمدی و زعفران',
    image: IMAGE_ASSETS.syrups,
    category: 'syrups' as CategorySlug,
  },
  {
    season: 'پاییز',
    title: 'ترشیجات پاییزی',
    description: 'ترشی مخلوط و لیته خانگی با سبزیجات تازه فصل',
    image: IMAGE_ASSETS.pickles,
    category: 'pickles' as CategorySlug,
  },
  {
    season: 'زمستان',
    title: 'خوراکی‌های زمستانی',
    description: 'رنگینک گردویی و مزه‌های گرم عصرهای سرد',
    image: IMAGE_ASSETS.localFoods,
    category: 'local-foods' as CategorySlug,
  },
];

const INSTAGRAM_TILES = [
  { id: 'ig-1', image: IMAGE_ASSETS.heroTable, caption: 'سفره صبحانه و عرقیجات تازه' },
  { id: 'ig-2', image: IMAGE_ASSETS.pickles, caption: 'بسته‌بندی کتان ترشی مخلوط' },
  { id: 'ig-3', image: IMAGE_ASSETS.jams, caption: 'مربای به یاقوتی و رب انار' },
  { id: 'ig-4', image: IMAGE_ASSETS.distillates, caption: 'تقطیر سنتی نعنا و گلاب' },
  { id: 'ig-5', image: IMAGE_ASSETS.spices, caption: 'سماق و ادویه‌های دست‌چین' },
  { id: 'ig-6', image: IMAGE_ASSETS.brandStory, caption: 'پشت صحنه آشپزخانه گلابتون' },
];

export function HomePage({
  wishlistIds,
  onNavigate,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
  onOpenRecipe,
}: HomePageProps) {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterDone, setNewsletterDone] = useState(false);
  const [newsletterError, setNewsletterError] = useState('');

  const bestSellers = PRODUCTS.slice(0, 8);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      setNewsletterError('لطفاً یک نشانی ایمیل معتبر وارد کنید.');
      return;
    }
    setNewsletterError('');
    setNewsletterDone(true);
    setNewsletterEmail('');
  };

  return (
    <div className="bg-persian-ivory pb-20">
      {/* 1. BACKGROUND A: ROYAL PERSIAN HERO SECTION */}
      <section className="relative bg-royal-persian text-[#F4E8D0] border-b-2 border-[#D5A52E]/55 overflow-hidden">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Editorial Copy + Official Logo (Right in RTL) */}
            <div className="lg:col-span-6 flex flex-col items-start space-y-6">
              <div className="flex items-center gap-4">
                <OfficialLogo size="hero" />
                <div className="space-y-1.5">
                  <p className="text-xs font-semibold text-[#D5A52E] tracking-wide">
                    عطر اصالت، طعم خونه
                  </p>
                  <p className="font-latin-serif text-xs tracking-[0.26em] text-[#E6D2A5] uppercase">
                    GOLABTOON SHOP
                  </p>
                  <div className="h-px w-20 bg-[#D5A52E]/60" />
                </div>
              </div>

              <h1 className="font-display-fa text-4xl sm:text-5xl lg:text-[3.35rem] leading-[1.3] text-[#F4E8D0]">
                به دنیای طعم‌های اصیل خوش آمدید
              </h1>

              <p className="text-base sm:text-lg text-[#E6D2A5]/95 leading-relaxed max-w-xl">
                گلابتون شاپ؛ جایی که عطر خاطره، زیبایی سنت و طعم‌های دوست‌داشتنی ایرانی در کنار هم قرار می‌گیرند.
              </p>

              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('shop', 'all')}
                  className="px-7 py-3.5 rounded-xl bg-[#D5A52E] text-[#100D0B] border border-[#E6D2A5]/60 text-sm font-bold hover:bg-[#E6D2A5] transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap shadow-md"
                >
                  <span>ورود به فروشگاه</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('about')}
                  className="px-6 py-3.5 rounded-xl bg-[#100D0B]/40 border border-[#D5A52E]/65 text-[#F4E8D0] text-sm font-semibold hover:bg-[#D5A52E]/15 transition-colors cursor-pointer whitespace-nowrap"
                >
                  داستان گلابتون
                </button>
              </div>
            </div>

            {/* Hero Framed Persian Palace Food Showcase (Left in RTL) */}
            <div className="lg:col-span-6">
              <div className="relative p-2.5 sm:p-3.5 rounded-[2rem] bg-[#100D0B]/55 border border-[#D5A52E]/60 shadow-2xl">
                <div className="absolute top-2 right-2 z-20">
                  <RoyalCornerOrnament position="top-right" />
                </div>
                <div className="absolute top-2 left-2 z-20">
                  <RoyalCornerOrnament position="top-left" />
                </div>
                <div className="relative aspect-[16/11] rounded-3xl overflow-hidden border border-[#D5A52E]/40">
                  <BrandImage
                    src={IMAGE_ASSETS.heroTable}
                    alt="میز چوبی سنتی ایرانی با شیشه‌های عرقیجات گیاهی، ترشی خانگی، مربای به و گلبرگ‌های گل محمدی"
                    loading="eager"
                    className="w-full h-full"
                  />
                  <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#100D0B]/85 via-[#100D0B]/30 to-transparent pointer-events-none" />
                  <div className="absolute bottom-4 right-5 left-5 flex items-end justify-between text-[#F4E8D0]">
                    <div>
                      <p className="text-xs text-[#D5A52E] font-medium">گلچین دست‌ساز آشپزخانه ایرانی</p>
                      <p className="text-sm sm:text-base font-semibold mt-0.5">
                        ترشی‌های خانگی، عرقیجات معطر و مرباهای اصیل
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. BACKGROUND C: ROYAL TILEWORK & PERSIAN ARCH CATEGORY SECTION */}
      <section className="bg-royal-tilework py-16 md:py-20 border-b-2 border-[#D5A52E]/45">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12 text-[#F4E8D0]">
            <div>
              <p className="text-xs font-semibold text-[#D5A52E] mb-2">ایوان طعم‌های اصیل</p>
              <h2 className="font-display-fa text-3xl sm:text-4xl">
                از دنیای گلابتون انتخاب کنید
              </h2>
              <p className="text-sm sm:text-base text-[#E6D2A5]/85 mt-1.5">
                هر سلیقه‌ای، یک طعم دوست‌داشتنی
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('shop', 'all')}
              className="text-sm font-semibold text-[#D5A52E] hover:text-[#F4E8D0] flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <span>همه دسته‌بندی‌ها</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {CATEGORIES.map((category) => (
              <button
                key={category.slug}
                type="button"
                onClick={() => onNavigate('shop', category.slug)}
                className="group relative text-right bg-[#173D30]/90 hover:bg-[#100D0B]/90 border border-[#D5A52E]/55 rounded-t-[4.5rem] rounded-b-2xl p-3 pb-5 transition-all duration-200 hover:-translate-y-1 hover:border-[#D5A52E] hover:shadow-2xl cursor-pointer flex flex-col"
              >
                {/* Persian Arch Window Frame */}
                <div className="aspect-[4/3] w-full overflow-hidden rounded-t-[3.8rem] rounded-b-xl border border-[#D5A52E]/45 bg-[#100D0B]">
                  <BrandImage
                    src={category.image}
                    alt={category.title}
                    className="w-full h-full transition-transform duration-300 group-hover:scale-[1.05]"
                  />
                </div>
                <div className="px-3 pt-4 flex-1 flex flex-col justify-between gap-3">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <h3 className="text-lg font-bold text-[#F4E8D0] group-hover:text-[#D5A52E] transition-colors">
                        {category.title}
                      </h3>
                      <span className="text-xs text-[#E6D2A5]/80">{category.seasonTag}</span>
                    </div>
                    <p className="text-sm text-[#E6D2A5]/85 leading-relaxed">
                      {category.description}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D5A52E] pt-2">
                    <span>مشاهده محصولات</span>
                    <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. BACKGROUND B: PERSIAN IVORY BEST SELLERS GRID */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2.5">
          <PersianDivider />
          <h2 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">
            محبوب‌ترین طعم‌های گلابتون
          </h2>
          <p className="text-sm sm:text-base text-[#60412E]/85">
            محصولاتی که جای خودشان را در دل مشتریان باز کرده‌اند
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {bestSellers.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isWishlisted={wishlistIds.includes(product.id)}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            type="button"
            onClick={() => onNavigate('shop', 'all')}
            className="px-8 py-3.5 rounded-xl bg-[#173D30] border border-[#D5A52E]/60 text-[#F4E8D0] text-sm font-semibold hover:bg-[#286044] transition-colors cursor-pointer"
          >
            مشاهده همه محصولات
          </button>
        </div>
      </section>

      {/* 4. BACKGROUND D: ROSE GARDEN BRAND STORY & VALUES */}
      <section className="bg-rose-garden text-[#F4E8D0] border-y-2 border-[#D5A52E]/45 py-16 md:py-20">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            <div className="lg:col-span-6">
              <div className="p-2 rounded-3xl border border-[#D5A52E]/50 bg-[#100D0B]/40 shadow-xl">
                <div className="aspect-[16/11] rounded-2xl overflow-hidden">
                  <BrandImage
                    src={IMAGE_ASSETS.brandStory}
                    alt="آشپزخانه سنتی گلابتون شاپ با سبد سبزی تازه، گلبرگ گل محمدی و شیشه‌های مربا و ترشی"
                    className="w-full h-full"
                  />
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 space-y-5">
              <p className="text-xs font-semibold text-[#D5A52E]">داستان یک طعم اصیل</p>
              <h2 className="font-display-fa text-3xl sm:text-4xl text-[#F4E8D0] leading-snug">
                بعضی طعم‌ها، بوی خاطره می‌دهند...
              </h2>
              <p className="text-base text-[#E6D2A5]/90 leading-loose">
                گلابتون شاپ از عشق به خوراکی‌های خانگی و طعم‌های اصیل ایرانی الهام گرفته است. از عطر گیاهان خوشبو تا ترشی‌های رنگارنگ و مرباهای دلنشین، هر محصول یادآور سادگی، صمیمیت و گرمای خانه است.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('about')}
                  className="px-6 py-3 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-bold hover:bg-[#E6D2A5] transition-colors inline-flex items-center gap-2 cursor-pointer"
                >
                  <span>بیشتر درباره ما بدانید</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 4 Brand Values */}
          <div className="pt-10 border-t border-[#D5A52E]/25">
            <h3 className="text-xl font-bold text-[#F4E8D0] mb-8 text-center">
              چرا گلابتون شاپ؟
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  num: '۰۱',
                  title: 'طعم‌های اصیل',
                  desc: 'تجربه طعم‌های آشنا و دوست‌داشتنی ایرانی با دستورپخت‌های خانگی.',
                  icon: Flower2,
                },
                {
                  num: '۰۲',
                  title: 'توجه به کیفیت',
                  desc: 'اهمیت دادن به انتخاب مواد اولیه تازه و دقت در تمام مراحل آماده‌سازی.',
                  icon: ShieldCheck,
                },
                {
                  num: '۰۳',
                  title: 'حس خوب خانگی',
                  desc: 'محصولاتی با الهام از هنر، صبوری و سلیقه سفره‌آرایی خانه‌های ایرانی.',
                  icon: HeartHandshake,
                },
                {
                  num: '۰۴',
                  title: 'بسته‌بندی با سلیقه',
                  desc: 'توجه به زیبایی ظروف شیشه‌ای، جزئیات پارچه کتان و ارسال ایمن سفارش‌ها.',
                  icon: PackageCheck,
                },
              ].map((val) => {
                const Icon = val.icon;
                return (
                  <div
                    key={val.num}
                    className="bg-[#100D0B]/45 p-6 rounded-2xl border border-[#D5A52E]/35 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <Icon className="w-6 h-6 text-[#D5A52E]" strokeWidth={1.6} />
                      <span className="text-xs font-semibold text-[#B51F2A] bg-[#F4E8D0] px-2 py-0.5 rounded tabular-nums">
                        {val.num}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-[#F4E8D0]">{val.title}</h4>
                    <p className="text-sm text-[#E6D2A5]/85 leading-relaxed">{val.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 5. Featured Royal Collection Banner + 5 Seasonal Products */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-16">
        <div className="relative rounded-3xl overflow-hidden border-2 border-[#D5A52E]/60 min-h-[320px] sm:min-h-[380px] flex items-center bg-[#100D0B]">
          <BrandImage
            src={IMAGE_ASSETS.heroTable}
            alt="مجموعه خوراکی‌های اصیل گلابتون"
            className="absolute inset-0 w-full h-full opacity-70"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-[#100D0B]/92 via-[#173D30]/80 to-[#173D30]/35" />
          <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-2xl space-y-5 text-[#F4E8D0]">
            <div className="flex items-center gap-2 text-xs text-[#D5A52E]">
              <Sparkles className="w-4 h-4" />
              <span>مجموعه برگزیده سفره ایرانی</span>
            </div>
            <h2 className="font-display-fa text-3xl sm:text-4xl lg:text-5xl leading-tight">
              مزه‌های اصیل، برای لحظه‌های ناب
            </h2>
            <p className="text-sm sm:text-base text-[#E6D2A5]/90 leading-relaxed">
              انتخابی خوش‌طعم برای سفره‌های گرم و دورهمی‌های دوست‌داشتنی؛ ترکیبی از ترشی‌های ترد، شربت‌های معطر و مرباهای خانگی.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('shop', 'all')}
              className="px-7 py-3 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-bold hover:bg-[#E6D2A5] transition-colors cursor-pointer"
            >
              کشف محصولات گلابتون
            </button>
          </div>
        </div>

        {/* 5 Seasonal Products */}
        <div>
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-display-fa text-2xl sm:text-3xl text-[#173D30]">
                طعم هر فصل در گلابتون
              </h2>
              <p className="text-sm text-[#60412E]/80 mt-1">
                پیشنهادهای فصلی متناسب با حال‌وهوای هر زمان از سال
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {SEASONAL_ITEMS.map((item) => (
              <button
                key={item.title}
                type="button"
                onClick={() => onNavigate('shop', item.category)}
                className="group text-right rounded-2xl overflow-hidden border border-[#D5A52E]/40 bg-[#FBF6EB] hover:border-[#D5A52E] hover:shadow-md transition-all cursor-pointer flex flex-col"
              >
                <div className="aspect-[4/3] overflow-hidden w-full">
                  <BrandImage
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full transition-transform duration-300 group-hover:scale-[1.04]"
                  />
                </div>
                <div className="p-4 space-y-1.5 flex-1">
                  <span className="text-xs font-semibold text-[#B51F2A]">{item.season}</span>
                  <h3 className="text-sm sm:text-base font-bold text-[#173D30]">{item.title}</h3>
                  <p className="text-xs text-[#60412E]/85 leading-relaxed">{item.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Recipes & Food Inspiration */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold text-[#176D79] mb-1.5">مجله آشپزی و پذیرایی</p>
            <h2 className="font-display-fa text-3xl sm:text-4xl text-[#173D30]">
              آشپزی با عطر خاطره
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {RECIPES.map((recipe) => (
            <article
              key={recipe.id}
              onClick={() => onOpenRecipe(recipe)}
              className="group bg-[#FBF6EB] border border-[#D5A52E]/35 rounded-2xl overflow-hidden flex flex-col justify-between hover:border-[#D5A52E] hover:shadow-lg transition-all cursor-pointer"
            >
              <div>
                <div className="aspect-[4/3] overflow-hidden bg-[#E6D2A5]/45">
                  <BrandImage
                    src={recipe.image}
                    alt={recipe.title}
                    className="w-full h-full transition-transform duration-300 group-hover:scale-[1.04]"
                  />
                </div>
                <div className="p-4 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs text-[#176D79] font-medium">
                    <span>{recipe.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {recipe.readingTime}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-[#173D30] leading-snug group-hover:text-[#B51F2A] transition-colors">
                    {recipe.title}
                  </h3>
                  <p className="text-xs text-[#60412E]/85 leading-relaxed line-clamp-2">
                    {recipe.excerpt}
                  </p>
                </div>
              </div>
              <div className="px-4 pb-4 pt-2">
                <span className="text-xs font-semibold text-[#173D30] inline-flex items-center gap-1.5">
                  <span>مطالعه مطلب</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* 7. Customer Testimonials + Instagram + Newsletter */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* Testimonials */}
        <div>
          <div className="text-center mb-10 space-y-2">
            <PersianDivider />
            <h2 className="font-display-fa text-3xl text-[#173D30]">
              خاطره‌های خوش از گلابتون
            </h2>
            <p className="text-xs text-[#60412E]/75">
              نمونه قالب دیدگاه‌های مشتریان (قابل ویرایش با نظرات واقعی فروشگاه)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {SAMPLE_REVIEWS.map((rev) => (
              <div
                key={rev.id}
                className="bg-[#FBF6EB] border border-[#D5A52E]/40 rounded-2xl p-6 space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-[#D5A52E]">
                      {Array.from({ length: rev.rating }).map((_, idx) => (
                        <Star key={idx} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    {rev.purchasedProduct && (
                      <span className="text-[11px] text-[#176D79] font-medium">
                        محصول: {rev.purchasedProduct}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-[#60412E] leading-relaxed">«{rev.comment}»</p>
                </div>
                <div className="pt-3 border-t border-[#D5A52E]/25 flex items-center justify-between text-xs text-[#176D79]">
                  <span className="font-semibold text-[#173D30]">{rev.author}</span>
                  <span>{rev.city}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Instagram Gallery */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
            <div>
              <h2 className="font-display-fa text-2xl sm:text-3xl text-[#173D30]">
                گلابتون را دنبال کنید
              </h2>
              <p className="text-sm text-[#60412E]/85 mt-1">
                از محصولات تازه تا لحظه‌های خوشمزه پشت صحنه
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('contact')}
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#173D30] hover:text-[#B51F2A] cursor-pointer"
            >
              <Instagram className="w-4 h-4" />
              <span>مشاهده صفحه اینستاگرام (@golabtoon.shop)</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {INSTAGRAM_TILES.map((tile) => (
              <div
                key={tile.id}
                className="group relative aspect-square rounded-2xl overflow-hidden border border-[#D5A52E]/40 bg-[#E6D2A5]/45"
              >
                <BrandImage
                  src={tile.image}
                  alt={tile.caption}
                  className="w-full h-full transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-[#173D30]/75 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                  <p className="text-[11px] text-[#F4E8D0] leading-snug">{tile.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Newsletter */}
        <div className="bg-royal-persian text-[#F4E8D0] border-2 border-[#D5A52E]/55 rounded-3xl p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-5">
          <div className="flex justify-center">
            <OfficialLogo size="sm" />
          </div>
          <h2 className="font-display-fa text-2xl sm:text-3xl">
            همیشه از طعم‌های تازه باخبر باشید
          </h2>
          <p className="text-sm sm:text-base text-[#E6D2A5]/90 max-w-xl mx-auto">
            برای اطلاع از محصولات جدید فصلی، پیشنهادهای ویژه و دستورهای خوشمزه همراه ما باشید.
          </p>

          {newsletterDone ? (
            <div className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>عضویت شما در خبرنامه گلابتون شاپ با موفقیت ثبت شد.</span>
            </div>
          ) : (
            <form
              onSubmit={handleNewsletterSubmit}
              className="max-w-md mx-auto flex flex-col sm:flex-row gap-2.5 pt-1"
            >
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="آدرس ایمیل شما"
                className="flex-1 h-12 px-4 rounded-xl bg-[#F4E8D0] border border-[#D5A52E]/50 text-sm text-[#100D0B] placeholder:text-[#60412E]/60 focus:outline-none focus:border-[#D5A52E]"
              />
              <button
                type="submit"
                className="h-12 px-6 rounded-xl bg-[#D5A52E] text-[#100D0B] text-sm font-bold hover:bg-[#E6D2A5] transition-colors whitespace-nowrap cursor-pointer"
              >
                عضویت در خبرنامه
              </button>
            </form>
          )}
          {newsletterError && (
            <p className="text-xs text-[#E6D2A5] font-medium">{newsletterError}</p>
          )}
          <p className="text-[11px] text-[#E6D2A5]/65">
            شماره تماس و نشانی‌های نمایش‌داده‌شده در نسخه پیش‌نمایش کاملاً قابل ویرایش هستند ({toPersianDigits(1405)}).
          </p>
        </div>
      </section>
    </div>
  );
}
