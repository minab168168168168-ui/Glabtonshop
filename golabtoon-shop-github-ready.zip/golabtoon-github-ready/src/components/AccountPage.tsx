import { useState } from 'react';
import {
  Heart,
  LogOut,
  MapPin,
  Package,
  Plus,
  Settings,
  Trash2,
  User,
} from 'lucide-react';
import { PRODUCTS, PROVINCES } from '../data/catalog';
import { OrderRecord, PageView, Product, SavedAddress, UserProfile } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { ProductCard } from './ProductCard';

interface AccountPageProps {
  profile: UserProfile;
  orders: OrderRecord[];
  addresses: SavedAddress[];
  wishlistIds: string[];
  onUpdateProfile: (profile: UserProfile) => void;
  onAddAddress: (addr: SavedAddress) => void;
  onDeleteAddress: (id: string) => void;
  onSelectProduct: (productId: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  onNavigate: (page: PageView) => void;
}

type AccountTab = 'profile' | 'orders' | 'addresses' | 'wishlist' | 'settings';

export function AccountPage({
  profile,
  orders,
  addresses,
  wishlistIds,
  onUpdateProfile,
  onAddAddress,
  onDeleteAddress,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
  onNavigate,
}: AccountPageProps) {
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authName, setAuthName] = useState('');
  const [authMobile, setAuthMobile] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [activeTab, setActiveTab] = useState<AccountTab>('orders');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(orders[0]?.id ?? null);
  const [savedNotice, setSavedNotice] = useState('');

  const [showAddressForm, setShowAddressForm] = useState(false);
  const [addrTitle, setAddrTitle] = useState('');
  const [addrProvince, setAddrProvince] = useState('تهران');
  const [addrCity, setAddrCity] = useState('');
  const [addrFull, setAddrFull] = useState('');
  const [addrPostal, setAddrPostal] = useState('');

  const wishlistedProducts = PRODUCTS.filter((p) => wishlistIds.includes(p.id));

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      isAuthenticated: true,
      fullName: authMode === 'register' && authName.trim() ? authName.trim() : 'مشتری گرامی گلابتون',
      mobile: authMobile.trim() || '09120000000',
      email: 'customer@golabtoonshop.example',
    });
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrTitle.trim() || !addrCity.trim() || !addrFull.trim()) return;
    onAddAddress({
      id: `addr-${Date.now()}`,
      title: addrTitle.trim(),
      recipient: profile.fullName,
      mobile: profile.mobile,
      province: addrProvince,
      city: addrCity.trim(),
      address: addrFull.trim(),
      postalCode: addrPostal.trim() || '1234567890',
    });
    setAddrTitle('');
    setAddrCity('');
    setAddrFull('');
    setAddrPostal('');
    setShowAddressForm(false);
  };

  if (!profile.isAuthenticated) {
    return (
      <div className="bg-persian-ivory">
        <div className="max-w-md mx-auto px-4 py-14 pb-24">
          <div className="bg-[#FBF6EB] border border-[#D5A52E]/55 rounded-3xl p-7 sm:p-8 space-y-6 shadow-sm">
            <div className="text-center space-y-1.5">
              <h1 className="font-display-fa text-3xl text-[#173D30]">
                {authMode === 'login' ? 'ورود به گلابتون شاپ' : 'ساخت حساب کاربری'}
              </h1>
              <p className="text-xs text-[#60412E]/80">
                برای مشاهده سفارش‌ها، آدرس‌ها و علاقه‌مندی‌ها وارد شوید
              </p>
            </div>

            <div className="grid grid-cols-2 p-1 rounded-xl bg-[#F4E8D0] border border-[#D5A52E]/35">
              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className={`py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  authMode === 'login' ? 'bg-[#173D30] text-[#F4E8D0]' : 'text-[#60412E]'
                }`}
              >
                ورود
              </button>
              <button
                type="button"
                onClick={() => setAuthMode('register')}
                className={`py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  authMode === 'register' ? 'bg-[#173D30] text-[#F4E8D0]' : 'text-[#60412E]'
                }`}
              >
                ثبت‌نام
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {authMode === 'register' && (
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#173D30]">نام و نام خانوادگی</label>
                  <input
                    type="text"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    placeholder="نام کامل شما"
                    required
                    className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/45 border border-[#D5A52E]/45 text-sm"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">شماره موبایل</label>
                <input
                  type="tel"
                  dir="ltr"
                  value={authMobile}
                  onChange={(e) => setAuthMobile(e.target.value)}
                  placeholder="09123456789"
                  required
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/45 border border-[#D5A52E]/45 text-sm text-right tabular-nums"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#173D30]">رمز عبور</label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/45 border border-[#D5A52E]/45 text-sm"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#173D30] border border-[#D5A52E]/60 text-[#F4E8D0] text-sm font-bold hover:bg-[#286044] transition-colors cursor-pointer"
              >
                {authMode === 'login' ? 'ورود به پنل کاربری' : 'تکمیل ثبت‌نام'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-persian-ivory">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Deep Persian Emerald Sidebar */}
          <aside className="lg:col-span-3 bg-royal-persian text-[#F4E8D0] border border-[#D5A52E]/50 rounded-3xl p-6 space-y-6">
            <div className="pb-5 border-b border-[#D5A52E]/35">
              <p className="text-xs text-[#D5A52E]">خوش آمدید</p>
              <h1 className="text-lg font-bold mt-0.5">{profile.fullName}</h1>
              <p className="text-xs text-[#E6D2A5]/80 mt-1 tabular-nums">{profile.mobile}</p>
            </div>

            <nav className="space-y-1.5">
              {[
                { id: 'orders' as AccountTab, label: 'تاریخچه سفارش‌ها', icon: Package },
                { id: 'profile' as AccountTab, label: 'اطلاعات حساب', icon: User },
                { id: 'addresses' as AccountTab, label: 'آدرس‌های ذخیره شده', icon: MapPin },
                { id: 'wishlist' as AccountTab, label: 'لیست علاقه‌مندی‌ها', icon: Heart },
                { id: 'settings' as AccountTab, label: 'تنظیمات', icon: Settings },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                      activeTab === item.id
                        ? 'bg-[#D5A52E] text-[#100D0B] font-bold'
                        : 'text-[#E6D2A5] hover:bg-[#286044]/60'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <button
              type="button"
              onClick={() => onUpdateProfile({ ...profile, isAuthenticated: false })}
              className="w-full flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-xs font-medium text-[#E6D2A5] hover:text-[#F4E8D0] border border-[#D5A52E]/40 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>خروج از حساب</span>
            </button>
          </aside>

          {/* Main Ivory Panel */}
          <div className="lg:col-span-9 bg-[#FBF6EB] border border-[#D5A52E]/45 rounded-3xl p-6 sm:p-8 space-y-6">
            {activeTab === 'orders' && (
              <div className="space-y-5">
                <h2 className="text-xl font-bold text-[#173D30]">تاریخچه سفارش‌ها</h2>
                {orders.length === 0 ? (
                  <div className="py-10 text-center space-y-3">
                    <p className="text-sm text-[#60412E]/85">هنوز سفارشی ثبت نکرده‌اید.</p>
                    <button
                      type="button"
                      onClick={() => onNavigate('shop')}
                      className="px-5 py-2.5 rounded-xl bg-[#173D30] text-[#F4E8D0] text-xs font-semibold cursor-pointer"
                    >
                      شروع خرید
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div
                        key={order.id}
                        className="bg-[#F4E8D0]/45 border border-[#D5A52E]/40 rounded-2xl p-5 space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="space-y-1">
                            <p className="text-sm font-bold text-[#173D30] tabular-nums">
                              سفارش {order.orderNumber}
                            </p>
                            <p className="text-xs text-[#176D79]">
                              {order.createdAt} · {order.status}
                            </p>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-sm font-bold text-[#173D30] tabular-nums">
                              {formatToman(order.total)} تومان
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedOrderId(expandedOrderId === order.id ? null : order.id)
                              }
                              className="text-xs font-semibold text-[#B51F2A] cursor-pointer"
                            >
                              {expandedOrderId === order.id ? 'بستن جزئیات' : 'مشاهده جزئیات'}
                            </button>
                          </div>
                        </div>

                        {expandedOrderId === order.id && (
                          <div className="pt-4 border-t border-[#D5A52E]/25 space-y-3 text-xs text-[#60412E]">
                            <p>نشانی ارسال: {order.addressSummary}</p>
                            <p>روش ارسال: {order.deliveryMethod}</p>
                            <div className="space-y-1.5 pt-2">
                              {order.items.map((item) => (
                                <div key={`${item.productId}-${item.variantId}`} className="flex justify-between">
                                  <span>
                                    {item.name} ({item.variantLabel}) × {toPersianDigits(item.quantity)}
                                  </span>
                                  <span className="tabular-nums font-medium">
                                    {formatToman(item.price * item.quantity)} تومان
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'profile' && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSavedNotice('تغییرات اطلاعات حساب ذخیره شد.');
                  window.setTimeout(() => setSavedNotice(''), 2500);
                }}
                className="space-y-5 max-w-xl"
              >
                <h2 className="text-xl font-bold text-[#173D30]">اطلاعات حساب کاربری</h2>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#173D30]">نام و نام خانوادگی</label>
                  <input
                    type="text"
                    value={profile.fullName}
                    onChange={(e) => onUpdateProfile({ ...profile, fullName: e.target.value })}
                    className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#173D30]">شماره موبایل</label>
                  <input
                    type="tel"
                    dir="ltr"
                    value={profile.mobile}
                    onChange={(e) => onUpdateProfile({ ...profile, mobile: e.target.value })}
                    className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm text-right tabular-nums"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#173D30]">ایمیل</label>
                  <input
                    type="email"
                    dir="ltr"
                    value={profile.email}
                    onChange={(e) => onUpdateProfile({ ...profile, email: e.target.value })}
                    className="w-full h-11 px-3.5 rounded-xl bg-[#F4E8D0]/55 border border-[#D5A52E]/45 text-sm text-right"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#173D30] text-[#F4E8D0] text-sm font-semibold cursor-pointer"
                >
                  ذخیره اطلاعات
                </button>
                {savedNotice && <p className="text-xs text-[#173D30] font-semibold">{savedNotice}</p>}
              </form>
            )}

            {activeTab === 'addresses' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-[#173D30]">آدرس‌های ذخیره شده</h2>
                  <button
                    type="button"
                    onClick={() => setShowAddressForm((v) => !v)}
                    className="px-4 py-2 rounded-xl bg-[#173D30] text-[#F4E8D0] text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>افزودن آدرس جدید</span>
                  </button>
                </div>

                {showAddressForm && (
                  <form
                    onSubmit={handleSaveAddress}
                    className="p-5 bg-[#F4E8D0]/55 border border-[#D5A52E]/45 rounded-2xl grid grid-cols-1 sm:grid-cols-2 gap-4"
                  >
                    <input
                      type="text"
                      placeholder="عنوان آدرس (مثلاً خانه)"
                      value={addrTitle}
                      onChange={(e) => setAddrTitle(e.target.value)}
                      required
                      className="h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm"
                    />
                    <select
                      value={addrProvince}
                      onChange={(e) => setAddrProvince(e.target.value)}
                      className="h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm"
                    >
                      {PROVINCES.map((p) => (
                        <option key={p} value={p}>
                          {p}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="شهر"
                      value={addrCity}
                      onChange={(e) => setAddrCity(e.target.value)}
                      required
                      className="h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm"
                    />
                    <input
                      type="text"
                      placeholder="کد پستی"
                      value={addrPostal}
                      onChange={(e) => setAddrPostal(e.target.value)}
                      className="h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm tabular-nums"
                    />
                    <input
                      type="text"
                      placeholder="نشانی کامل"
                      value={addrFull}
                      onChange={(e) => setAddrFull(e.target.value)}
                      required
                      className="sm:col-span-2 h-10 px-3 rounded-xl bg-[#FBF6EB] border border-[#D5A52E]/40 text-sm"
                    />
                    <button
                      type="submit"
                      className="sm:col-span-2 py-2.5 rounded-xl bg-[#173D30] text-[#F4E8D0] text-sm font-semibold cursor-pointer"
                    >
                      ثبت آدرس
                    </button>
                  </form>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className="bg-[#F4E8D0]/45 border border-[#D5A52E]/40 rounded-2xl p-5 flex flex-col justify-between gap-3"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <h3 className="text-sm font-bold text-[#173D30]">{addr.title}</h3>
                          <button
                            type="button"
                            onClick={() => onDeleteAddress(addr.id)}
                            aria-label="حذف آدرس"
                            className="text-[#60412E]/60 hover:text-[#B51F2A] cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-xs text-[#60412E]/85 leading-relaxed">
                          {addr.province}، {addr.city}، {addr.address}
                        </p>
                        <p className="text-xs text-[#176D79] tabular-nums">کد پستی: {addr.postalCode}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'wishlist' && (
              <div className="space-y-5">
                <h2 className="text-xl font-bold text-[#173D30]">لیست علاقه‌مندی‌ها</h2>
                {wishlistedProducts.length === 0 ? (
                  <p className="text-sm text-[#60412E]/85 py-8">
                    هنوز محصولی به لیست علاقه‌مندی‌های خود اضافه نکرده‌اید.
                  </p>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {wishlistedProducts.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        isWishlisted
                        onSelect={onSelectProduct}
                        onAddToCart={onAddToCart}
                        onToggleWishlist={onToggleWishlist}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-4 max-w-lg">
                <h2 className="text-xl font-bold text-[#173D30]">تنظیمات اعلان و حساب</h2>
                <label className="flex items-center justify-between p-4 rounded-2xl bg-[#F4E8D0]/45 border border-[#D5A52E]/35 cursor-pointer">
                  <span className="text-sm text-[#173D30]">اطلاع‌رسانی محصولات فصلی جدید</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4 accent-[#173D30]" />
                </label>
                <label className="flex items-center justify-between p-4 rounded-2xl bg-[#F4E8D0]/45 border border-[#D5A52E]/35 cursor-pointer">
                  <span className="text-sm text-[#173D30]">ارسال پیامک وضعیت آماده‌سازی سفارش</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4 accent-[#173D30]" />
                </label>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
