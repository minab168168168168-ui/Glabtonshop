import { useState } from 'react';
import { Flower2 } from 'lucide-react';

interface BrandImageProps {
  src: string;
  alt: string;
  className?: string;
  aspectClass?: string;
  loading?: 'eager' | 'lazy';
}

export function BrandImage({
  src,
  alt,
  className = '',
  aspectClass = '',
  loading = 'lazy',
}: BrandImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`relative flex flex-col items-center justify-center bg-[#EEE5D4] text-[#49382D]/70 overflow-hidden ${aspectClass} ${className}`}
        role="img"
        aria-label={alt}
      >
        <Flower2 className="w-8 h-8 text-[#68744B]/60 mb-2" strokeWidth={1.3} />
        <span className="text-xs px-4 text-center line-clamp-2 text-[#49382D]/75">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading={loading}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={`object-cover ${aspectClass} ${className}`}
    />
  );
}
