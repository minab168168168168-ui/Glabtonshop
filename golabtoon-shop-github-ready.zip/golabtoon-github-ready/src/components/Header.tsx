import { useEffect, useState } from 'react';
import {
  ChevronDown,
  Heart,
  Home,
  LayoutGrid,
  Menu,
  Search,
  ShoppingBag,
  User,
  X,
} from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../data/catalog';
import { CategorySlug, PageView } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';
import { BrandLockup, OfficialLogo } from './BrandMark';

interface HeaderProps {
  currentPage: PageView;
  activeCategory: CategorySlug;
  cartCount: number;
  wishlistCount: number;
  isAuthenticated: boolean;
  onNavigate: (page: PageView, category?: CategorySlug) => void;
  onSelectProduct: (productId: string) => void;
  onOpenSearch: () => void;
}

const ANNOUNCEMENTS = [
  'به دنیای خوش‌طعم گلابتون شاپ خوش آمدید 🌿',
  'طعم‌های اصیل و خانگی، با عشق برای شما',
  'از دل طبیعت، به سفره‌های گرم شما',
];

export function Header({
  currentPage,
  activeCategory,
  cartCount,
  wishlistCount,
  isAuthenticated,
  onNavigate,
  onSelectProduct,
  onOpenSearch,
}: HeaderProps) {
  const [showAnnouncement, setShowAnnouncement] = useState(true);
  const [announcementIdx, setAnnouncementIdx] = useState(0);
  const [megaOpen, setMegaOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setAnnouncementIdx((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, 5000);
    return () => window.clearInterval(timer);
  }, []);

  const handleNavClick = (page: PageView, category?: CategorySlug) => {
    setMegaOpen(false);
    setMobileMenuOpen(false);
    onNavigate(page, category);
  };

  return (
    <>
      {showAnnouncement && (
        <div className="bg-[#100D0B] text-[#E6D2A5] h-9 px-4 flex items-center justify-between text-xs border-b border-[#D5A52E]/30">
          <div className="w-6 shrink-0" />
          <p className="truncate text-center font-normal tracking-normal">
            {ANNOUNCEMENTS[announcementIdx]}
          </p>
          <button
            type="button"
            onClick={() => setShowAnnouncement(false)}
            aria-label="بستن نوار اعلان"
            className="w-6 h-6 flex items-center justify-center text-[#E6D2A5]/75 hover:text-[#D5A52E] transition-colors cursor-pointer shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <header
        className="sticky top-0 z-40 bg-[#173D30] text-[#F4E8D0] border-b border-[#D5A52E]/45 shadow-md"
        onMouseLeave={() => setMegaOpen(false)}
      >
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6 lg:px-8 h-16 lg:h-20 flex items-center justify-between gap-4">
          {/* RIGHT (in RTL): Mobile Menu + Desktop Navigation Links */}
          <div className="flex items-center gap-2 lg:gap-4 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="باز کردن منوی موبایل"
              className="lg:hidden w-10 h-10 flex items-center justify-center rounded-lg text-[#F4E8D0] hover:bg-[#286044] transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            <nav
              aria-label="منوی اصلی"
              className="hidden lg:flex items-center gap-4 xl:gap-5 text-[13px] font-medium text-[#E6D2A5]"
            >
              <button
                type="button"
                onClick={() => handleNavClick('home')}
                className={`py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'home'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                خانه
              </button>

              <div className="relative" onMouseEnter={() => setMegaOpen(true)}>
                <button
                  type="button"
                  onClick={() => handleNavClick('shop', 'all')}
                  aria-expanded={megaOpen}
                  className={`py-2 flex items-center gap-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                    currentPage === 'shop' && activeCategory === 'all'
                      ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                      : 'border-transparent hover:text-[#D5A52E]'
                  }`}
                >
                  <span>فروشگاه</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      megaOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleNavClick('shop', 'distillates')}
                className={`py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'shop' && activeCategory === 'distillates'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                عرقیجات
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('shop', 'pickles')}
                className={`py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'shop' && activeCategory === 'pickles'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                ترشیجات
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('shop', 'jams')}
                className={`py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'shop' && activeCategory === 'jams'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                مربا و فرآورده‌ها
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('shop', 'local-foods')}
                className={`hidden xl:inline-block py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'shop' && activeCategory === 'local-foods'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                خوراکی‌های خانگی
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('about')}
                className={`py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  currentPage === 'about'
                    ? 'border-[#D5A52E] text-[#F4E8D0] font-semibold'
                    : 'border-transparent hover:text-[#D5A52E]'
                }`}
              >
                درباره ما
              </button>
            </nav>
          </div>

          {/* CENTER: Official Uploaded Golabtoon Logo + Title & Slogan */}
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer shrink-0 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-4"
          >
            <OfficialLogo size="sm" />
            <span className="hidden sm:flex flex-col items-start leading-none">
              <span className="font-display-fa text-xl sm:text-2xl text-[#F4E8D0]">
                گلابتون شاپ
              </span>
              <span className="text-[10px] text-[#D5A52E] mt-1 font-medium">
                عطر اصالت، طعم خونه
              </span>
            </span>
          </button>

          {/* LEFT (in RTL): Search, Account, Wishlist, Shopping Cart */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenSearch}
              aria-label="جستجوی محصولات"
              className="w-10 h-10 flex items-center justify-center rounded-lg text-[#E6D2A5] hover:bg-[#286044] hover:text-[#F4E8D0] transition-colors cursor-pointer"
            >
              <Search className="w-[18px] h-[18px]" strokeWidth={1.7} />
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('account')}
              aria-label="حساب کاربری"
              className="hidden sm:flex w-10 h-10 items-center justify-center rounded-lg text-[#E6D2A5] hover:bg-[#286044] hover:text-[#F4E8D0] transition-colors cursor-pointer relative"
            >
              <User className="w-[18px] h-[18px]" strokeWidth={1.7} />
              {isAuthenticated && <span className="sr-only">وارد شده</span>}
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('account')}
              aria-label="علاقه‌مندی‌ها"
              className="hidden sm:flex w-10 h-10 items-center justify-center rounded-lg text-[#E6D2A5] hover:bg-[#286044] hover:text-[#F4E8D0] transition-colors cursor-pointer relative"
            >
              <Heart className="w-[18px] h-[18px]" strokeWidth={1.7} />
              {wishlistCount > 0 && (
                <span className="absolute top-1.5 left-1.5 min-w-[16px] h-4 px-1 rounded-full bg-[#B51F2A] text-[#F4E8D0] text-[10px] font-semibold flex items-center justify-center tabular-nums">
                  {toPersianDigits(wishlistCount)}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('cart')}
              aria-label="سبد خرید"
              className="flex items-center gap-2 h-10 px-3 sm:px-4 rounded-lg bg-[#D5A52E] text-[#100D0B] hover:bg-[#E6D2A5] transition-colors cursor-pointer whitespace-nowrap shrink-0 font-semibold"
            >
              <ShoppingBag className="w-4 h-4 shrink-0" strokeWidth={1.9} />
              <span className="text-xs hidden sm:inline">سبد خرید</span>
              <span className="min-w-[20px] h-5 px-1.5 rounded-md bg-[#100D0B] text-[#F4E8D0] text-xs font-bold flex items-center justify-center tabular-nums">
                {toPersianDigits(cartCount)}
              </span>
            </button>
          </div>
        </div>

        {/* Desktop Royal Mega Menu */}
        {megaOpen && (
          <div className="hidden lg:block absolute top-full inset-x-0 bg-[#F7EFE0] text-[#60412E] border-b-2 border-[#D5A52E]/60 shadow-2xl z-50">
            <div className="max-w-[1280px] mx-auto px-8 py-8 grid grid-cols-12 gap-8">
              <div className="col-span-7">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#B88B37]/25">
                  <h3 className="text-sm font-bold text-[#173D30]">دسته‌بندی طعم‌های گلابتون</h3>
                  <button
                    type="button"
                    onClick={() => handleNavClick('shop', 'all')}
                    className="text-xs text-[#176D79] hover:text-[#173D30] font-semibold cursor-pointer"
                  >
                    مشاهده همه محصولات
                  </button>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.slug}
                      type="button"
                      onClick={() => handleNavClick('shop', cat.slug)}
                      className="group flex items-center gap-3 p-2.5 rounded-xl border border-transparent hover:border-[#D5A52E]/45 hover:bg-[#F4E8D0] transition-colors text-right cursor-pointer"
                    >
                      <BrandImage
                        src={cat.image}
                        alt={cat.title}
                        className="w-14 h-14 rounded-lg shrink-0 border border-[#D5A52E]/30"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-[#173D30] group-hover:text-[#B51F2A] transition-colors truncate">
                          {cat.title}
                        </p>
                        <p className="text-xs text-[#60412E]/75 mt-0.5 truncate">
                          {cat.seasonTag}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="col-span-5 border-r border-[#B88B37]/25 pr-8">
                <h3 className="text-sm font-bold text-[#173D30] mb-4 pb-2 border-b border-[#B88B37]/25">
                  برگزیده‌های پرطرفدار
                </h3>
                <div className="space-y-3">
                  {PRODUCTS.slice(0, 3).map((product) => (
                    <button
                      key={product.id}
                      type="button"
                      onClick={() => {
                        setMegaOpen(false);
                        onSelectProduct(product.id);
                      }}
                      className="w-full flex items-center justify-between gap-3 p-2 rounded-xl hover:bg-[#F4E8D0] transition-colors text-right cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <BrandImage
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 rounded-lg shrink-0 border border-[#D5A52E]/30"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#173D30] truncate">{product.name}</p>
                          <p className="text-xs text-[#60412E]/75">{product.weight}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-[#173D30] tabular-nums whitespace-nowrap">
                        {formatToman(product.price)} تومان
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Slide-Out Royal Emerald Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#100D0B]/60 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-80 max-w-[85vw] bg-[#173D30] text-[#F4E8D0] h-full shadow-2xl flex flex-col border-l border-[#D5A52E]/40 z-10">
            <div className="p-5 flex items-center justify-between border-b border-[#D5A52E]/30">
              <BrandLockup light compact onClick={() => handleNavClick('home')} />
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="بستن منو"
                className="w-10 h-10 flex items-center justify-center rounded-lg text-[#E6D2A5] hover:bg-[#286044] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              <div className="space-y-1">
                <p className="text-xs font-medium text-[#D5A52E] mb-2">مسیرهای اصلی</p>
                {[
                  { label: 'صفحه اصلی', page: 'home' as PageView },
                  { label: 'فروشگاه محصولات', page: 'shop' as PageView },
                  { label: 'قصه گلابتون (درباره ما)', page: 'about' as PageView },
                  { label: 'سوالات متداول', page: 'faq' as PageView },
                  { label: 'تماس با ما', page: 'contact' as PageView },
                  { label: 'سبد خرید', page: 'cart' as PageView },
                  { label: 'حساب کاربری', page: 'account' as PageView },
                ].map((item) => (
                  <button
                    key={item.page}
                    type="button"
                    onClick={() => handleNavClick(item.page, item.page === 'shop' ? 'all' : undefined)}
                    className={`w-full text-right px-3 py-3 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                      currentPage === item.page
                        ? 'bg-[#D5A52E] text-[#100D0B] font-bold'
                        : 'text-[#E6D2A5] hover:bg-[#286044]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="pt-4 border-t border-[#D5A52E]/25">
                <p className="text-xs font-medium text-[#D5A52E] mb-3">دسته‌بندی‌ها</p>
                <div className="grid grid-cols-2 gap-2">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.slug}
                      type="button"
                      onClick={() => handleNavClick('shop', cat.slug)}
                      className="text-right p-2.5 rounded-lg bg-[#100D0B]/40 border border-[#D5A52E]/25 hover:border-[#D5A52E] text-xs font-medium text-[#F4E8D0] cursor-pointer"
                    >
                      {cat.shortTitle}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Fixed Compact Mobile Bottom Navigation (Deep Emerald + Gold) */}
      <nav
        aria-label="ناوبری سریع موبایل"
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 h-14 bg-[#173D30] text-[#E6D2A5] border-t border-[#D5A52E]/45 grid grid-cols-5 items-center px-1"
      >
        <button
          type="button"
          onClick={() => handleNavClick('home')}
          className={`flex flex-col items-center justify-center gap-0.5 h-full text-[11px] cursor-pointer ${
            currentPage === 'home' ? 'text-[#D5A52E] font-semibold' : 'text-[#E6D2A5]/80'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>خانه</span>
        </button>

        <button
          type="button"
          onClick={() => handleNavClick('shop', 'all')}
          className={`flex flex-col items-center justify-center gap-0.5 h-full text-[11px] cursor-pointer ${
            currentPage === 'shop' ? 'text-[#D5A52E] font-semibold' : 'text-[#E6D2A5]/80'
          }`}
        >
          <LayoutGrid className="w-4 h-4" />
          <span>دسته‌بندی</span>
        </button>

        <button
          type="button"
          onClick={onOpenSearch}
          className="flex flex-col items-center justify-center gap-0.5 h-full text-[11px] text-[#E6D2A5]/80 cursor-pointer"
        >
          <Search className="w-4 h-4" />
          <span>جستجو</span>
        </button>

        <button
          type="button"
          onClick={() => handleNavClick('account')}
          className={`flex flex-col items-center justify-center gap-0.5 h-full text-[11px] relative cursor-pointer ${
            currentPage === 'account' ? 'text-[#D5A52E] font-semibold' : 'text-[#E6D2A5]/80'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>علاقه‌مندیها</span>
        </button>

        <button
          type="button"
          onClick={() => handleNavClick('cart')}
          className={`flex flex-col items-center justify-center gap-0.5 h-full text-[11px] relative cursor-pointer ${
            currentPage === 'cart' || currentPage === 'checkout'
              ? 'text-[#D5A52E] font-semibold'
              : 'text-[#E6D2A5]/80'
          }`}
        >
          <div className="relative">
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -left-2 min-w-[15px] h-[15px] px-1 rounded-full bg-[#B51F2A] text-[#F4E8D0] text-[9px] flex items-center justify-center tabular-nums">
                {toPersianDigits(cartCount)}
              </span>
            )}
          </div>
          <span>سبد خرید</span>
        </button>
      </nav>
    </>
  );
}
