import { Check, Heart, ShoppingBag, Star } from 'lucide-react';
import { useState } from 'react';
import { Product } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/format';
import { BrandImage } from './BrandImage';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onSelect: (productId: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
}

export function ProductCard({
  product,
  isWishlisted,
  onSelect,
  onAddToCart,
  onToggleWishlist,
}: ProductCardProps) {
  const [justAdded, setJustAdded] = useState(false);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    onAddToCart(product);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1200);
  };

  return (
    <article className="group flex flex-col bg-[#FBF6EB] border border-[#D5A52E]/40 rounded-2xl overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:border-[#D5A52E] hover:shadow-xl">
      {/* Image area */}
      <div
        onClick={() => onSelect(product.id)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelect(product.id);
          }
        }}
        className="relative aspect-[4/3] w-full bg-[#E6D2A5]/45 overflow-hidden cursor-pointer border-b border-[#D5A52E]/25"
      >
        <BrandImage
          src={product.image}
          alt={product.name}
          className="w-full h-full transition-transform duration-300 group-hover:scale-[1.04]"
        />

        {/* Wishlist icon button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          aria-label={isWishlisted ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'}
          className={`absolute top-3 left-3 w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer border ${
            isWishlisted
              ? 'bg-[#B51F2A] border-[#D5A52E]/60 text-[#F4E8D0]'
              : 'bg-[#F4E8D0]/95 border-[#D5A52E]/40 text-[#60412E] hover:text-[#B51F2A]'
          }`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Single quiet editorial label (crimson accent for special tags) */}
        {!product.inStock ? (
          <span className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md bg-[#100D0B]/85 text-[#F4E8D0] text-[11px] font-medium border border-[#D5A52E]/35">
            ناموجود موقت
          </span>
        ) : product.badge ? (
          <span className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md bg-[#B51F2A] text-[#F4E8D0] text-[11px] font-semibold shadow-sm">
            {product.badge}
          </span>
        ) : null}
      </div>

      {/* Product Metadata & Action */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          <div className="flex items-center justify-between gap-2 text-xs text-[#176D79] font-medium mb-1.5">
            <span className="truncate">
              {product.categoryLabel} · {product.weight}
            </span>
            <span
              title="امتیاز نمونه قابل ویرایش"
              className="inline-flex items-center gap-1 text-[#60412E] shrink-0 tabular-nums"
            >
              <Star className="w-3 h-3 text-[#D5A52E] fill-[#D5A52E]" />
              <span>{toPersianDigits(product.ratingPlaceholder)}</span>
            </span>
          </div>

          <h3
            onClick={() => onSelect(product.id)}
            className="text-sm sm:text-base font-bold text-[#173D30] leading-snug cursor-pointer group-hover:text-[#B51F2A] transition-colors line-clamp-2"
          >
            {product.name}
          </h3>

          <button
            type="button"
            onClick={() => onSelect(product.id)}
            className="mt-1.5 text-[11px] font-semibold text-[#B88B37] hover:text-[#173D30] transition-colors cursor-pointer"
          >
            مشاهده جزئیات محصول ←
          </button>
        </div>

        <div className="pt-3 border-t border-[#D5A52E]/25 flex items-center justify-between gap-2">
          <div className="flex items-baseline gap-1">
            <span className="text-base font-bold text-[#173D30] tabular-nums">
              {formatToman(product.price)}
            </span>
            <span className="text-[11px] text-[#60412E]/80">تومان</span>
          </div>

          <button
            type="button"
            disabled={!product.inStock}
            onClick={handleQuickAdd}
            className={`h-9 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer border ${
              !product.inStock
                ? 'bg-[#E6D2A5]/60 border-[#B88B37]/25 text-[#60412E]/50 cursor-not-allowed'
                : justAdded
                ? 'bg-[#286044] border-[#D5A52E] text-[#F4E8D0]'
                : 'bg-[#173D30] border-[#D5A52E]/45 text-[#F4E8D0] hover:bg-[#286044]'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>افزوده شد</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{product.inStock ? 'افزودن' : 'ناموجود'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
