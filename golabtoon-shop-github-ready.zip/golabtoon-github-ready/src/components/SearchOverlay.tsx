import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Search, X } from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../data/catalog';
import { CategorySlug } from '../types/store';
import { formatToman } from '../utils/format';
import { BrandImage } from './BrandImage';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (productId: string) => void;
  onSelectCategory: (category: CategorySlug) => void;
}

const RECENT_SEARCHES_INITIAL = ['عرق نعنا', 'ترشی مخلوط', 'رب انار', 'مربای به'];

export function SearchOverlay({
  isOpen,
  onClose,
  onSelectProduct,
  onSelectCategory,
}: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(RECENT_SEARCHES_INITIAL);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      window.setTimeout(() => inputRef.current?.focus(), 80);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const trimmed = query.trim();
  const matches = trimmed
    ? PRODUCTS.filter(
        (p) =>
          p.name.includes(trimmed) ||
          p.categoryLabel.includes(trimmed) ||
          p.shortDescription.includes(trimmed)
      )
    : [];

  const handleChooseQuery = (term: string) => {
    setQuery(term);
    if (!recentSearches.includes(term)) {
      setRecentSearches((prev) => [term, ...prev].slice(0, 5));
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-20 px-4"
      role="dialog"
      aria-modal="true"
      aria-label="جستجو در فروشگاه گلابتون"
    >
      <div
        className="fixed inset-0 bg-[#100D0B]/70 backdrop-blur-xs"
        onClick={onClose}
      />
      <div className="relative z-10 w-full max-w-2xl bg-[#F7EFE0] rounded-2xl border-2 border-[#D5A52E]/60 shadow-2xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#D5A52E]/35 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#176D79] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="دنبال چه طعمی می‌گردید؟"
            className="w-full bg-transparent text-[#173D30] placeholder:text-[#60412E]/55 text-sm sm:text-base focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="text-xs text-[#176D79] hover:text-[#173D30] px-2 py-1 cursor-pointer"
            >
              پاک کردن
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="بستن جستجو"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-[#60412E] hover:bg-[#E6D2A5]/50 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 max-h-[70vh] overflow-y-auto space-y-6">
          {!trimmed ? (
            <>
              <div>
                <h4 className="text-xs font-bold text-[#176D79] mb-3">جستجوهای اخیر</h4>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((term) => (
                    <button
                      key={term}
                      type="button"
                      onClick={() => handleChooseQuery(term)}
                      className="px-3 py-1.5 rounded-lg bg-[#E6D2A5]/60 hover:bg-[#D5A52E]/35 text-xs font-semibold text-[#173D30] transition-colors cursor-pointer border border-[#D5A52E]/30"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold text-[#176D79] mb-3">دسته‌بندی‌های محبوب</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.slug}
                      type="button"
                      onClick={() => {
                        onSelectCategory(cat.slug);
                        onClose();
                      }}
                      className="flex items-center gap-2.5 p-2 rounded-xl border border-[#D5A52E]/35 hover:bg-[#E6D2A5]/45 transition-colors text-right cursor-pointer"
                    >
                      <BrandImage
                        src={cat.image}
                        alt={cat.title}
                        className="w-10 h-10 rounded-lg shrink-0"
                      />
                      <span className="text-xs font-semibold text-[#173D30] truncate">
                        {cat.shortTitle}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : matches.length > 0 ? (
            <div className="space-y-2">
              <p className="text-xs text-[#176D79] font-medium mb-2">نتایج یافت‌شده</p>
              {matches.map((product) => (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => {
                    onSelectProduct(product.id);
                    onClose();
                  }}
                  className="w-full flex items-center justify-between gap-4 p-2.5 rounded-xl hover:bg-[#E6D2A5]/50 transition-colors text-right cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <BrandImage
                      src={product.image}
                      alt={product.name}
                      className="w-14 h-12 rounded-lg shrink-0 border border-[#D5A52E]/30"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-[#173D30] truncate">{product.name}</p>
                      <p className="text-xs text-[#176D79]">
                        {product.categoryLabel} · {product.weight}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-bold text-[#173D30] tabular-nums">
                      {formatToman(product.price)} تومان
                    </span>
                    <ArrowLeft className="w-4 h-4 text-[#D5A52E]" />
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center space-y-3">
              <p className="text-sm font-semibold text-[#173D30]">
                محصولی با عبارت «{trimmed}» پیدا نشد.
              </p>
              <p className="text-xs text-[#60412E]/80">
                می‌توانید نام دسته‌بندی‌هایی مثل عرق، ترشی، مربا یا شربت را امتحان کنید.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
