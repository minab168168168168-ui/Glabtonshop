export const OFFICIAL_LOGO_URL =
  '/assets/aistudio/ChatGPT_Image_Nov_15__2026__04_12_17_PM_1e7c5e95.jpg';

export function OfficialLogo({
  size = 'md',
  className = '',
}: {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'hero';
  className?: string;
}) {
  const sizeClasses = {
    xs: 'w-11 h-11 rounded-xl p-0.5',
    sm: 'w-14 h-14 rounded-xl p-0.5',
    md: 'w-16 h-16 rounded-2xl p-1',
    lg: 'w-24 h-24 rounded-2xl p-1',
    hero: 'w-36 h-36 sm:w-44 sm:h-44 rounded-3xl p-1.5',
  }[size];

  return (
    <div
      className={`bg-[#100D0B] border border-[#D5A52E]/70 shadow-md overflow-hidden shrink-0 flex items-center justify-center ${sizeClasses} ${className}`}
    >
      <img
        src={OFFICIAL_LOGO_URL}
        alt="لوگوی رسمی گلابتون شاپ"
        className="w-full h-full object-contain"
      />
    </div>
  );
}

export function PersianDivider({ light = false }: { light?: boolean }) {
  const lineClass = light ? 'bg-[#D5A52E]/40' : 'bg-[#B88B37]/45';
  const strokeColor = light ? '#D5A52E' : '#B88B37';
  const accentColor = '#B51F2A';

  return (
    <div className="flex items-center justify-center gap-4 my-2" aria-hidden="true">
      <div className={`h-px flex-1 max-w-[140px] ${lineClass}`} />
      <svg width="42" height="20" viewBox="0 0 42 20" fill="none">
        <path
          d="M21 2C24.5 6.5 29 8.5 39 10C29 11.5 24.5 13.5 21 18C17.5 13.5 13 11.5 3 10C13 8.5 17.5 6.5 21 2Z"
          stroke={strokeColor}
          strokeWidth="1.2"
        />
        <circle cx="21" cy="10" r="2.6" fill={accentColor} stroke={strokeColor} strokeWidth="0.9" />
      </svg>
      <div className={`h-px flex-1 max-w-[140px] ${lineClass}`} />
    </div>
  );
}

export function RoyalCornerOrnament({
  position = 'top-right',
}: {
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
}) {
  const rotate = {
    'top-right': 'rotate-0',
    'top-left': '-scale-x-100',
    'bottom-right': '-scale-y-100',
    'bottom-left': 'rotate-180',
  }[position];

  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={`w-9 h-9 pointer-events-none ${rotate}`}
    >
      <path d="M44 4H12C7.58172 4 4 7.58172 4 12V44" stroke="#D5A52E" strokeWidth="1.4" opacity="0.7" />
      <path d="M36 9H15C11.6863 9 9 11.6863 9 15V36" stroke="#176D79" strokeWidth="1" opacity="0.55" />
      <circle cx="10" cy="10" r="2.5" fill="#B51F2A" stroke="#D5A52E" strokeWidth="0.9" />
    </svg>
  );
}

export function BrandLockup({
  light = false,
  compact = false,
  onClick,
}: {
  light?: boolean;
  compact?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-3 text-right focus-visible:outline-2 focus-visible:outline-offset-4 cursor-pointer shrink-0 whitespace-nowrap"
    >
      <OfficialLogo size={compact ? 'xs' : 'sm'} />
      <span className="flex flex-col items-start leading-none">
        <span
          className={`font-display-fa tracking-normal ${
            compact ? 'text-xl' : 'text-2xl'
          } ${light ? 'text-[#F4E8D0]' : 'text-[#173D30]'}`}
        >
          گلابتون شاپ
        </span>
        {!compact && (
          <span
            className={`font-latin-serif text-[10px] tracking-[0.22em] uppercase mt-1 ${
              light ? 'text-[#E6D2A5]' : 'text-[#60412E]/80'
            }`}
          >
            GOLABTOON SHOP
          </span>
        )}
      </span>
    </button>
  );
}
