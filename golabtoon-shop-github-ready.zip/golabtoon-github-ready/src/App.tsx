import { useEffect, useState } from 'react';
import { AccountPage } from './components/AccountPage';
import { CartPage, CheckoutPage } from './components/CartCheckoutPages';
import { AboutPage, ContactPage, FaqPage, RecipeModal } from './components/EditorialPages';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { ProductDetailPage } from './components/ProductDetailPage';
import { SearchOverlay } from './components/SearchOverlay';
import { ShopPage } from './components/ShopPage';
import { PRODUCTS } from './data/catalog';
import {
  CartItem,
  CategorySlug,
  OrderRecord,
  PageView,
  Product,
  RecipeArticle,
  SavedAddress,
  UserProfile,
} from './types/store';

const STORAGE_KEYS = {
  cart: 'golabtoon_cart_v1',
  wishlist: 'golabtoon_wishlist_v1',
  orders: 'golabtoon_orders_v1',
  addresses: 'golabtoon_addresses_v1',
  profile: 'golabtoon_profile_v1',
};

const INITIAL_ADDRESSES: SavedAddress[] = [
  {
    id: 'addr-1',
    title: 'نشانی پیش‌فرض (قابل ویرایش)',
    recipient: 'نام گیرنده قابل ویرایش',
    mobile: '09120000000',
    province: 'تهران',
    city: 'تهران',
    address: 'نشانی نمونه قابل ویرایش',
    postalCode: '1415512345',
    isDefault: true,
  },
];

function parseHashRoute(): { page: PageView; category: CategorySlug; productId?: string } {
  const raw = window.location.hash.replace(/^#\/?/, '');
  const parts = raw.split('/').filter(Boolean);
  if (parts[0] === 'product' && parts[1]) {
    const found = PRODUCTS.find((p) => p.slug === parts[1] || p.id === parts[1]);
    if (found) return { page: 'product', category: found.category, productId: found.id };
  }
  if (parts[0] === 'shop') {
    const cat = (parts[1] as CategorySlug) || 'all';
    return { page: 'shop', category: cat };
  }
  if (
    parts[0] === 'cart' ||
    parts[0] === 'checkout' ||
    parts[0] === 'account' ||
    parts[0] === 'about' ||
    parts[0] === 'contact' ||
    parts[0] === 'faq'
  ) {
    return { page: parts[0], category: 'all' };
  }
  return { page: 'home', category: 'all' };
}

export default function App() {
  const initialRoute = parseHashRoute();
  const [currentPage, setCurrentPage] = useState<PageView>(initialRoute.page);
  const [activeCategory, setActiveCategory] = useState<CategorySlug>(initialRoute.category);
  const [selectedProductId, setSelectedProductId] = useState<string>(
    initialRoute.productId ?? PRODUCTS[0].id
  );
  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>([PRODUCTS[0].id, PRODUCTS[3].id]);

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.cart);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.wishlist);
      return saved ? JSON.parse(saved) : ['p-1', 'p-6'];
    } catch {
      return ['p-1', 'p-6'];
    }
  });

  const [orders, setOrders] = useState<OrderRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.orders);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [addresses, setAddresses] = useState<SavedAddress[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.addresses);
      return saved ? JSON.parse(saved) : INITIAL_ADDRESSES;
    } catch {
      return INITIAL_ADDRESSES;
    }
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.profile);
      return saved
        ? JSON.parse(saved)
        : {
            isAuthenticated: false,
            fullName: 'مشتری گرامی گلابتون',
            mobile: '09120000000',
            email: 'hello@golabtoonshop.example',
          };
    } catch {
      return {
        isAuthenticated: false,
        fullName: 'مشتری گرامی گلابتون',
        mobile: '09120000000',
        email: 'hello@golabtoonshop.example',
      };
    }
  });

  const [discountCode, setDiscountCode] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeRecipe, setActiveRecipe] = useState<RecipeArticle | null>(null);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    const onHashChange = () => {
      const next = parseHashRoute();
      setCurrentPage(next.page);
      setActiveCategory(next.category);
      if (next.productId) setSelectedProductId(next.productId);
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify(cartItems));
    } catch {
      // Ignore storage quota errors
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.wishlist, JSON.stringify(wishlistIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify(orders));
    } catch {
      // Ignore storage quota errors
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.addresses, JSON.stringify(addresses));
    } catch {
      // Ignore storage quota errors
    }
  }, [addresses]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.profile, JSON.stringify(profile));
    } catch {
      // Ignore storage quota errors
    }
  }, [profile]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => setToastMessage(''), 2500);
  };

  const navigateTo = (page: PageView, category?: CategorySlug) => {
    const targetCategory = category ?? (page === 'shop' ? activeCategory : 'all');
    if (category) {
      setActiveCategory(category);
    }
    setCurrentPage(page);
    if (page === 'home') {
      window.location.hash = '/';
    } else if (page === 'shop') {
      window.location.hash = targetCategory === 'all' ? '/shop' : `/shop/${targetCategory}`;
    } else {
      window.location.hash = `/${page}`;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (productId: string) => {
    const product = PRODUCTS.find((p) => p.id === productId);
    setSelectedProductId(productId);
    setRecentlyViewedIds((prev) => [productId, ...prev.filter((id) => id !== productId)].slice(0, 6));
    setCurrentPage('product');
    if (product) {
      window.location.hash = `/product/${product.slug}`;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (
    product: Product,
    quantity = 1,
    variantId?: string,
    variantLabel?: string,
    price?: number
  ) => {
    if (!product.inStock) return;
    const effectiveVariantId = variantId ?? product.variants?.[product.variants.length - 1]?.id;
    const effectiveVariantLabel = variantLabel ?? product.weight;
    const effectivePrice = price ?? product.price;

    setCartItems((prev) => {
      const existing = prev.find(
        (item) => item.productId === product.id && item.variantId === effectiveVariantId
      );
      if (existing) {
        return prev.map((item) =>
          item.productId === product.id && item.variantId === effectiveVariantId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          variantId: effectiveVariantId,
          variantLabel: effectiveVariantLabel,
          name: product.name,
          categoryLabel: product.categoryLabel,
          price: effectivePrice,
          image: product.image,
          quantity,
        },
      ];
    });
    showToast(`«${product.name}» به سبد خرید اضافه شد.`);
  };

  const handleUpdateQty = (productId: string, variantId: string | undefined, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.productId === productId && item.variantId === variantId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (productId: string, variantId: string | undefined) => {
    setCartItems((prev) =>
      prev.filter((item) => !(item.productId === productId && item.variantId === variantId))
    );
  };

  const handleToggleWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(productId);
      const next = exists ? prev.filter((id) => id !== productId) : [productId, ...prev];
      showToast(exists ? 'از لیست علاقه‌مندی‌ها حذف شد.' : 'به لیست علاقه‌مندی‌ها اضافه شد.');
      return next;
    });
  };

  const handlePlaceOrder = (order: OrderRecord) => {
    setOrders((prev) => [order, ...prev]);
    setCartItems([]);
    setDiscountCode('');
    if (!profile.isAuthenticated) {
      setProfile((prev) => ({
        ...prev,
        isAuthenticated: true,
        fullName: order.recipientName,
        mobile: order.mobile,
      }));
    }
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const selectedProduct = PRODUCTS.find((p) => p.id === selectedProductId) ?? PRODUCTS[0];

  return (
    <div className="min-h-screen flex flex-col bg-[#F7EFE0] text-[#60412E]">
      <Header
        currentPage={currentPage}
        activeCategory={activeCategory}
        cartCount={cartCount}
        wishlistCount={wishlistIds.length}
        isAuthenticated={profile.isAuthenticated}
        onNavigate={navigateTo}
        onSelectProduct={handleSelectProduct}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            wishlistIds={wishlistIds}
            onNavigate={navigateTo}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onToggleWishlist={handleToggleWishlist}
            onOpenRecipe={setActiveRecipe}
          />
        )}

        {currentPage === 'shop' && (
          <ShopPage
            initialCategory={activeCategory}
            wishlistIds={wishlistIds}
            onCategoryChange={(cat) => navigateTo('shop', cat)}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onToggleWishlist={handleToggleWishlist}
          />
        )}

        {currentPage === 'product' && (
          <ProductDetailPage
            key={selectedProduct.id}
            product={selectedProduct}
            wishlistIds={wishlistIds}
            recentlyViewedIds={recentlyViewedIds}
            onNavigate={navigateTo}
            onSelectProduct={handleSelectProduct}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
          />
        )}

        {currentPage === 'cart' && (
          <CartPage
            items={cartItems}
            discountCode={discountCode}
            onApplyDiscount={setDiscountCode}
            onUpdateQty={handleUpdateQty}
            onRemoveItem={handleRemoveItem}
            onNavigate={(page) => navigateTo(page)}
          />
        )}

        {currentPage === 'checkout' && (
          <CheckoutPage
            items={cartItems}
            discountCode={discountCode}
            savedAddresses={addresses}
            onPlaceOrder={handlePlaceOrder}
            onNavigate={(page) => navigateTo(page)}
          />
        )}

        {currentPage === 'account' && (
          <AccountPage
            profile={profile}
            orders={orders}
            addresses={addresses}
            wishlistIds={wishlistIds}
            onUpdateProfile={setProfile}
            onAddAddress={(addr) => setAddresses((prev) => [addr, ...prev])}
            onDeleteAddress={(id) => setAddresses((prev) => prev.filter((a) => a.id !== id))}
            onSelectProduct={handleSelectProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onToggleWishlist={handleToggleWishlist}
            onNavigate={(page) => navigateTo(page)}
          />
        )}

        {currentPage === 'about' && <AboutPage onNavigate={navigateTo} />}
        {currentPage === 'contact' && <ContactPage />}
        {currentPage === 'faq' && <FaqPage onNavigate={(page) => navigateTo(page)} />}
      </main>

      <Footer onNavigate={navigateTo} />

      <SearchOverlay
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={handleSelectProduct}
        onSelectCategory={(cat) => navigateTo('shop', cat)}
      />

      <RecipeModal
        recipe={activeRecipe}
        onClose={() => setActiveRecipe(null)}
        onExploreCategory={(cat) => navigateTo('shop', cat)}
      />

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-28 lg:bottom-6 left-4 sm:left-6 z-50 px-5 py-3 rounded-xl bg-[#100D0B] text-[#F4E8D0] text-xs sm:text-sm font-medium shadow-2xl border border-[#D5A52E]/65 flex items-center gap-3"
        >
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => navigateTo('cart')}
            className="text-xs underline underline-offset-4 text-[#D5A52E] hover:text-[#F4E8D0] cursor-pointer"
          >
            سبد خرید
          </button>
        </div>
      )}
    </div>
  );
}
